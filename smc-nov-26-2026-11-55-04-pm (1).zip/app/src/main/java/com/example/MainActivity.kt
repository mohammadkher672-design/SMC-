package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.SmcBottomBar
import com.example.ui.components.SmcToastBanner
import com.example.ui.components.SmcTopBar
import com.example.ui.screens.ArchiveScreen
import com.example.ui.screens.CalculatorScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.OrdersScreen
import com.example.ui.theme.SmcCablesTheme
import com.example.ui.theme.SmcTheme
import com.example.viewmodel.AppTab
import com.example.viewmodel.FactoryViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            val factoryViewModel: FactoryViewModel = viewModel()
            val uiState by factoryViewModel.uiState.collectAsStateWithLifecycle()

            SideEffect {
                val style = if (uiState.isDarkTheme) {
                    SystemBarStyle.dark(Color.TRANSPARENT)
                } else {
                    SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                }
                enableEdgeToEdge(
                    statusBarStyle = style,
                    navigationBarStyle = style
                )
            }

            SmcCablesTheme(darkTheme = uiState.isDarkTheme) {
                SmcCablesAppRoot(viewModel = factoryViewModel)
            }
        }
    }
}

@Composable
private fun SmcCablesAppRoot(viewModel: FactoryViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val colors = SmcTheme.colors
    var currentTab by rememberSaveable { mutableStateOf(AppTab.ORDERS) }

    BackHandler(enabled = currentTab != AppTab.ORDERS) {
        currentTab = AppTab.ORDERS
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        // Fixed Header + Scrollable Middle Content + Fixed Bottom Navigation Bar
        Column(modifier = Modifier.fillMaxSize()) {
            SmcTopBar(
                copperKg = uiState.copperKg,
                totalPlasticKg = uiState.totalPlasticKg,
                isDarkTheme = uiState.isDarkTheme,
                onToggleTheme = viewModel::toggleTheme,
                onQuickInventoryClick = { currentTab = AppTab.INVENTORY }
            )

            Box(
                contentAlignment = Alignment.TopCenter,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .widthIn(max = 720.dp)
                        .fillMaxSize()
                ) {
                    when (currentTab) {
                        AppTab.ORDERS -> OrdersScreen(
                            activeOrders = uiState.activeOrders,
                            presets = uiState.presets,
                            onAddPreset = viewModel::addPreset,
                            onDeletePreset = viewModel::deletePreset,
                            onSaveOrder = viewModel::saveOrder,
                            onToggleColorCheck = viewModel::toggleColorCheck,
                            onAdvanceStage2 = viewModel::advanceOrderToStage2,
                            onArchiveOrder = viewModel::archiveOrder,
                            onDeleteOrder = { id -> viewModel.deleteOrder(id, isArchived = false) }
                        )

                        AppTab.INVENTORY -> InventoryScreen(
                            copperItem = uiState.copperItem,
                            plasticItems = uiState.plasticItems,
                            totalPlasticKg = uiState.totalPlasticKg,
                            logs = uiState.logs,
                            onSetBalance = viewModel::setMaterialBalance,
                            onAdjustBalance = viewModel::adjustMaterialBalance,
                            onRenamePlastic = viewModel::renamePlastic,
                            onClearLogs = viewModel::clearInventoryLogs
                        )

                        AppTab.CALCULATOR -> CalculatorScreen(
                            state = uiState.calculator,
                            results = uiState.calculatorResults,
                            copperBalanceKg = uiState.copperKg,
                            plasticItems = uiState.plasticItems,
                            onCopperDiameterChange = viewModel::updateCopperDiameter,
                            onOuterDiameterChange = viewModel::updateOuterDiameter,
                            onPlasticDensityChange = viewModel::updatePlasticDensity,
                            onCopperDensityChange = viewModel::updateCopperDensity,
                            onLengthChange = viewModel::updateCalcLength,
                            onLengthUnitChange = viewModel::updateCalcLengthUnit,
                            onCoresChange = viewModel::updateCalcCores,
                            onDeductFromInventory = viewModel::deductCalculatorFromInventory
                        )

                        AppTab.ARCHIVE -> ArchiveScreen(
                            archivedOrders = uiState.archivedOrders,
                            onRestoreOrder = viewModel::restoreOrder,
                            onDeletePermanently = { id -> viewModel.deleteOrder(id, isArchived = true) }
                        )
                    }
                }

                // Floating In-App Toast Banner overlay at top of scrollable content
                SmcToastBanner(
                    toast = uiState.toast,
                    onDismiss = viewModel::dismissToast,
                    modifier = Modifier.align(Alignment.TopCenter)
                )
            }

            SmcBottomBar(
                currentTab = currentTab,
                activeOrdersCount = uiState.activeOrders.size,
                archivedOrdersCount = uiState.archivedOrders.size,
                onSelectTab = { currentTab = it }
            )
        }
    }
}

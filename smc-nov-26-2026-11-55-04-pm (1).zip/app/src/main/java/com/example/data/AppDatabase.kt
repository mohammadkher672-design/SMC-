package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

@Database(
    entities = [
        InventoryItemEntity::class,
        InventoryLogEntity::class,
        OrderEntity::class,
        PresetEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun factoryDao(): FactoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "smc_cables_factory.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}

object WireJsonSerializer {
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val listType = Types.newParameterizedType(List::class.java, WireLineSpec::class.java)
    private val adapter = moshi.adapter<List<WireLineSpec>>(listType)

    fun toJson(wires: List<WireLineSpec>): String = adapter.toJson(wires)

    fun fromJson(json: String): List<WireLineSpec> {
        return try {
            adapter.fromJson(json) ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }
}

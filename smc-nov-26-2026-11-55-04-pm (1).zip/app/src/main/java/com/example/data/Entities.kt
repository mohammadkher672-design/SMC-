package com.example.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "inventory_items")
data class InventoryItemEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val quantityKg: Double,
    val sortOrder: Int,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "inventory_logs")
data class InventoryLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val materialId: String,
    val materialName: String,
    val actionLabel: String,
    val deltaKg: Double,
    val resultingBalanceKg: Double,
    val note: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "factory_orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val orderNumber: String,
    val orderType: String,
    val insulationDetails: String,
    val stageMode: String,
    val stage1Name: String,
    val stage2Name: String,
    val currentStage: Int,
    val wiresJson: String,
    val isArchived: Boolean,
    val createdAt: Long = System.currentTimeMillis(),
    val archivedAt: Long? = null
)

@Entity(
    tableName = "saved_presets",
    indices = [Index(value = ["category", "value"], unique = true)]
)
data class PresetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val category: String,
    val value: String,
    val createdAt: Long = System.currentTimeMillis()
)

package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface FactoryDao {

    // Inventory Items
    @Query("SELECT * FROM inventory_items ORDER BY sortOrder ASC")
    fun observeInventory(): Flow<List<InventoryItemEntity>>

    @Query("SELECT * FROM inventory_items WHERE id = :id LIMIT 1")
    suspend fun getInventoryItemById(id: String): InventoryItemEntity?

    @Query("SELECT COUNT(*) FROM inventory_items")
    suspend fun countInventoryItems(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventoryItems(items: List<InventoryItemEntity>)

    @Update
    suspend fun updateInventoryItem(item: InventoryItemEntity)

    // Inventory Logs
    @Query("SELECT * FROM inventory_logs ORDER BY timestamp DESC, id DESC LIMIT 150")
    fun observeLogs(): Flow<List<InventoryLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: InventoryLogEntity)

    @Query("DELETE FROM inventory_logs")
    suspend fun clearAllLogs()

    // Orders (Active & Archive)
    @Query("SELECT * FROM factory_orders WHERE isArchived = 0 ORDER BY createdAt DESC, id DESC")
    fun observeActiveOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM factory_orders WHERE isArchived = 1 ORDER BY archivedAt DESC, id DESC")
    fun observeArchivedOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM factory_orders WHERE id = :orderId LIMIT 1")
    suspend fun getOrderById(orderId: Long): OrderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity): Long

    @Update
    suspend fun updateOrder(order: OrderEntity)

    @Query("DELETE FROM factory_orders WHERE id = :orderId")
    suspend fun deleteOrderById(orderId: Long)

    // Saved Presets
    @Query("SELECT * FROM saved_presets ORDER BY category ASC, id DESC")
    fun observePresets(): Flow<List<PresetEntity>>

    @Query("SELECT COUNT(*) FROM saved_presets")
    suspend fun countPresets(): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPreset(preset: PresetEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPresets(presets: List<PresetEntity>)

    @Query("DELETE FROM saved_presets WHERE id = :presetId")
    suspend fun deletePresetById(presetId: Long)
}

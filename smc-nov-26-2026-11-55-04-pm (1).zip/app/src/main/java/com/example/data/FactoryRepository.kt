package com.example.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

class FactoryRepository(
    private val database: AppDatabase,
    private val preferences: ThemePreferences
) {
    private val dao = database.factoryDao()

    val isDarkTheme: Flow<Boolean> = preferences.isDarkTheme
    val inventory: Flow<List<InventoryItemEntity>> = dao.observeInventory()
    val logs: Flow<List<InventoryLogEntity>> = dao.observeLogs()
    val presets: Flow<List<PresetEntity>> = dao.observePresets()

    val activeOrders: Flow<List<FactoryOrder>> = dao.observeActiveOrders().map { list ->
        list.map { it.toDomain() }
    }

    val archivedOrders: Flow<List<FactoryOrder>> = dao.observeArchivedOrders().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun setDarkTheme(isDark: Boolean) = preferences.setDarkTheme(isDark)

    suspend fun ensureSeeded() {
        val alreadySeeded = preferences.isSeeded.first()
        if (dao.countInventoryItems() == 0) {
            dao.insertInventoryItems(
                listOf(
                    InventoryItemEntity(
                        id = InventoryIds.COPPER,
                        name = "النحاس الخام",
                        category = MaterialCategory.COPPER.code,
                        quantityKg = 0.0,
                        sortOrder = 0
                    ),
                    InventoryItemEntity(
                        id = InventoryIds.PLASTIC_1,
                        name = "PVC عزل",
                        category = MaterialCategory.PLASTIC.code,
                        quantityKg = 0.0,
                        sortOrder = 1
                    ),
                    InventoryItemEntity(
                        id = InventoryIds.PLASTIC_2,
                        name = "PVC طري",
                        category = MaterialCategory.PLASTIC.code,
                        quantityKg = 0.0,
                        sortOrder = 2
                    ),
                    InventoryItemEntity(
                        id = InventoryIds.PLASTIC_3,
                        name = "XLPE حراري",
                        category = MaterialCategory.PLASTIC.code,
                        quantityKg = 0.0,
                        sortOrder = 3
                    )
                )
            )
        }
        if (!alreadySeeded && dao.countPresets() == 0) {
            val initialPresets = buildList {
                listOf("SMC-101", "SMC-102", "SMC-103").forEach {
                    add(PresetEntity(category = PresetCategory.ORDER_NUMBER.code, value = it))
                }
                listOf("سلك تمديدات منزلية", "كبل طاقة محلي", "كبل مرن متعدد الفردات", "كبل صناعي مسلح").forEach {
                    add(PresetEntity(category = PresetCategory.ORDER_TYPE.code, value = it))
                }
                listOf("PVC عزل قياسي 70°C", "PVC طري مرن", "XLPE حراري 90°C", "تلبيس PVC خارجي مقاوم").forEach {
                    add(PresetEntity(category = PresetCategory.INSULATION.code, value = it))
                }
                listOf(
                    "1.5 مم²", "2.5 مم²", "4 مم²", "6 مم²", "10 مم²", "16 مم²",
                    "2x1.5 مم²", "3x2.5 مم²", "4x4 مم²"
                ).forEach {
                    add(PresetEntity(category = PresetCategory.WIRE_TYPE.code, value = it))
                }
            }
            dao.insertPresets(initialPresets)
            preferences.markSeeded()
        } else if (!alreadySeeded) {
            preferences.markSeeded()
        }
    }

    suspend fun setMaterialBalance(materialId: String, newBalanceKg: Double, note: String) {
        val safeBalance = newBalanceKg.coerceAtLeast(0.0)
        database.withTransaction {
            val current = dao.getInventoryItemById(materialId) ?: return@withTransaction
            val delta = safeBalance - current.quantityKg
            val now = System.currentTimeMillis()
            dao.updateInventoryItem(current.copy(quantityKg = safeBalance, updatedAt = now))
            dao.insertLog(
                InventoryLogEntity(
                    materialId = current.id,
                    materialName = current.name,
                    actionLabel = "تحديث يدوي",
                    deltaKg = delta,
                    resultingBalanceKg = safeBalance,
                    note = note.ifBlank { "تعديل مباشر للرصيد" },
                    timestamp = now
                )
            )
        }
    }

    suspend fun adjustMaterialBalance(
        materialId: String,
        deltaKg: Double,
        actionLabel: String,
        note: String
    ) {
        if (deltaKg == 0.0) return
        database.withTransaction {
            val current = dao.getInventoryItemById(materialId) ?: return@withTransaction
            val newBalance = (current.quantityKg + deltaKg).coerceAtLeast(0.0)
            val actualDelta = newBalance - current.quantityKg
            val now = System.currentTimeMillis()
            dao.updateInventoryItem(current.copy(quantityKg = newBalance, updatedAt = now))
            dao.insertLog(
                InventoryLogEntity(
                    materialId = current.id,
                    materialName = current.name,
                    actionLabel = actionLabel,
                    deltaKg = actualDelta,
                    resultingBalanceKg = newBalance,
                    note = note.ifBlank { if (deltaKg > 0) "إضافة للمخزون" else "خصم من المخزون" },
                    timestamp = now
                )
            )
        }
    }

    suspend fun deductFromCalculator(
        copperKg: Double,
        plasticId: String,
        plasticKg: Double,
        note: String
    ) {
        database.withTransaction {
            val now = System.currentTimeMillis()
            val copper = dao.getInventoryItemById(InventoryIds.COPPER)
            if (copper != null && copperKg > 0.0) {
                val newCu = (copper.quantityKg - copperKg).coerceAtLeast(0.0)
                dao.updateInventoryItem(copper.copy(quantityKg = newCu, updatedAt = now))
                dao.insertLog(
                    InventoryLogEntity(
                        materialId = copper.id,
                        materialName = copper.name,
                        actionLabel = "خصم من الحاسبة",
                        deltaKg = newCu - copper.quantityKg,
                        resultingBalanceKg = newCu,
                        note = note,
                        timestamp = now
                    )
                )
            }
            val plastic = dao.getInventoryItemById(plasticId)
            if (plastic != null && plasticKg > 0.0) {
                val newPl = (plastic.quantityKg - plasticKg).coerceAtLeast(0.0)
                dao.updateInventoryItem(plastic.copy(quantityKg = newPl, updatedAt = now + 1))
                dao.insertLog(
                    InventoryLogEntity(
                        materialId = plastic.id,
                        materialName = plastic.name,
                        actionLabel = "خصم من الحاسبة",
                        deltaKg = newPl - plastic.quantityKg,
                        resultingBalanceKg = newPl,
                        note = note,
                        timestamp = now + 1
                    )
                )
            }
        }
    }

    suspend fun renameMaterial(materialId: String, newName: String) {
        val trimmed = newName.trim()
        if (trimmed.isEmpty()) return
        val current = dao.getInventoryItemById(materialId) ?: return
        if (current.name == trimmed) return
        dao.updateInventoryItem(current.copy(name = trimmed, updatedAt = System.currentTimeMillis()))
    }

    suspend fun clearAllLogs() = dao.clearAllLogs()

    suspend fun addPreset(category: PresetCategory, value: String) {
        val trimmed = value.trim()
        if (trimmed.isEmpty()) return
        dao.insertPreset(PresetEntity(category = category.code, value = trimmed))
    }

    suspend fun deletePreset(presetId: Long) = dao.deletePresetById(presetId)

    suspend fun saveOrder(order: FactoryOrder) {
        database.withTransaction {
            // Auto-save any newly typed custom values to saved presets
            if (order.orderNumber.isNotBlank()) {
                dao.insertPreset(PresetEntity(category = PresetCategory.ORDER_NUMBER.code, value = order.orderNumber.trim()))
            }
            if (order.orderType.isNotBlank()) {
                dao.insertPreset(PresetEntity(category = PresetCategory.ORDER_TYPE.code, value = order.orderType.trim()))
            }
            if (order.insulationDetails.isNotBlank()) {
                dao.insertPreset(PresetEntity(category = PresetCategory.INSULATION.code, value = order.insulationDetails.trim()))
            }
            order.wires.forEach { wire ->
                if (wire.wireType.isNotBlank()) {
                    dao.insertPreset(PresetEntity(category = PresetCategory.WIRE_TYPE.code, value = wire.wireType.trim()))
                }
            }

            val entity = order.toEntity()
            if (order.id == 0L) {
                dao.insertOrder(entity)
            } else {
                dao.updateOrder(entity)
            }
        }
    }

    suspend fun toggleColorCheck(orderId: Long, wireId: String, colorId: String) {
        val entity = dao.getOrderById(orderId) ?: return
        val order = entity.toDomain()
        val isStage2 = order.stageMode == OrderStageMode.TWO_STAGE && order.currentStage == 2
        val updatedWires = order.wires.map { wire ->
            if (wire.id != wireId) wire
            else wire.copy(
                colors = wire.colors.map { item ->
                    if (item.id != colorId) item
                    else if (isStage2) item.copy(stage2Done = !item.stage2Done)
                    else item.copy(stage1Done = !item.stage1Done)
                }
            )
        }
        dao.updateOrder(order.copy(wires = updatedWires).toEntity())
    }

    suspend fun advanceOrderToStage2(orderId: Long) {
        val entity = dao.getOrderById(orderId) ?: return
        val order = entity.toDomain()
        if (order.stageMode == OrderStageMode.TWO_STAGE && order.isStage1Complete) {
            dao.updateOrder(order.copy(currentStage = 2).toEntity())
        }
    }

    suspend fun archiveOrder(orderId: Long) {
        val entity = dao.getOrderById(orderId) ?: return
        dao.updateOrder(
            entity.copy(
                isArchived = true,
                archivedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun restoreOrder(orderId: Long) {
        val entity = dao.getOrderById(orderId) ?: return
        dao.updateOrder(
            entity.copy(
                isArchived = false,
                archivedAt = null
            )
        )
    }

    suspend fun deleteOrder(orderId: Long) = dao.deleteOrderById(orderId)

    private fun OrderEntity.toDomain(): FactoryOrder = FactoryOrder(
        id = id,
        orderNumber = orderNumber,
        orderType = orderType,
        insulationDetails = insulationDetails,
        stageMode = OrderStageMode.fromCode(stageMode),
        stage1Name = stage1Name,
        stage2Name = stage2Name,
        currentStage = currentStage,
        wires = WireJsonSerializer.fromJson(wiresJson),
        isArchived = isArchived,
        createdAt = createdAt,
        archivedAt = archivedAt
    )

    private fun FactoryOrder.toEntity(): OrderEntity = OrderEntity(
        id = id,
        orderNumber = orderNumber.trim(),
        orderType = orderType.trim(),
        insulationDetails = insulationDetails.trim(),
        stageMode = stageMode.code,
        stage1Name = stage1Name.trim().ifEmpty { FactoryOrder.DEFAULT_STAGE_1_NAME },
        stage2Name = stage2Name.trim().ifEmpty { FactoryOrder.DEFAULT_STAGE_2_NAME },
        currentStage = currentStage,
        wiresJson = WireJsonSerializer.toJson(wires),
        isArchived = isArchived,
        createdAt = createdAt,
        archivedAt = archivedAt
    )
}

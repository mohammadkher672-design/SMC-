package com.example.data

import com.squareup.moshi.JsonClass
import java.util.UUID
import kotlin.math.PI
import kotlin.math.pow

object InventoryIds {
    const val COPPER = "COPPER"
    const val PLASTIC_1 = "PLASTIC_1"
    const val PLASTIC_2 = "PLASTIC_2"
    const val PLASTIC_3 = "PLASTIC_3"
}

enum class MaterialCategory(val code: String) {
    COPPER("COPPER"),
    PLASTIC("PLASTIC")
}

enum class OrderStageMode(val code: String, val labelAr: String) {
    SINGLE_STAGE("SINGLE", "مرحلة واحدة"),
    TWO_STAGE("TWO_STAGE", "مرحلتين");

    companion object {
        fun fromCode(code: String): OrderStageMode =
            entries.firstOrNull { it.code == code } ?: SINGLE_STAGE
    }
}

enum class LengthUnit(val code: String, val labelAr: String, val shortAr: String) {
    METERS("M", "متر", "م"),
    KILOMETERS("KM", "كيلومتر", "كم");

    companion object {
        fun fromCode(code: String): LengthUnit =
            entries.firstOrNull { it.code == code } ?: METERS
    }
}

enum class PresetCategory(val code: String, val labelAr: String, val placeholderAr: String) {
    ORDER_NUMBER("ORDER_NUMBER", "أرقام الأوردرات", "مثال: SMC-205"),
    ORDER_TYPE("ORDER_TYPE", "أنواع الأوردرات", "مثال: كبل طاقة محلي"),
    INSULATION("INSULATION", "تفاصيل العزل", "مثال: PVC عزل قياسي 70°C"),
    WIRE_TYPE("WIRE_TYPE", "أنواع ومقاطع الأسلاك", "مثال: 2.5 مم²");

    companion object {
        fun fromCode(code: String): PresetCategory =
            entries.firstOrNull { it.code == code } ?: ORDER_NUMBER
    }
}

data class CableColorPreset(
    val name: String,
    val colorArgb: Long,
    val isDualGround: Boolean = false
)

val StandardCableColors: List<CableColorPreset> = listOf(
    CableColorPreset("أحمر", 0xFFDC2626),
    CableColorPreset("أسود", 0xFF1E293B),
    CableColorPreset("أزرق", 0xFF2563EB),
    CableColorPreset("أصفر", 0xFFEAB308),
    CableColorPreset("أخضر", 0xFF16A34A),
    CableColorPreset("أصفر/أخضر (أرضي)", 0xFFEAB308, isDualGround = true),
    CableColorPreset("بني", 0xFF92400E),
    CableColorPreset("رمادي", 0xFF64748B),
    CableColorPreset("أبيض", 0xFFF1F5F9),
    CableColorPreset("برتقالي", 0xFFEA580C),
    CableColorPreset("بنفسجي", 0xFF9333EA)
)

@JsonClass(generateAdapter = true)
data class ColorLengthItem(
    val id: String = UUID.randomUUID().toString(),
    val colorName: String,
    val colorArgb: Long,
    val isDualGround: Boolean = false,
    val lengthMeters: Double = 1000.0,
    val stage1Done: Boolean = false,
    val stage2Done: Boolean = false
)

@JsonClass(generateAdapter = true)
data class WireLineSpec(
    val id: String = UUID.randomUUID().toString(),
    val wireType: String,
    val preferredUnitCode: String = LengthUnit.METERS.code,
    val unifiedLength: Boolean = true,
    val colors: List<ColorLengthItem> = emptyList()
) {
    val preferredUnit: LengthUnit
        get() = LengthUnit.fromCode(preferredUnitCode)

    val totalMeters: Double
        get() = colors.sumOf { it.lengthMeters }
}

data class FactoryOrder(
    val id: Long = 0L,
    val orderNumber: String,
    val orderType: String,
    val insulationDetails: String,
    val stageMode: OrderStageMode = OrderStageMode.SINGLE_STAGE,
    val stage1Name: String = DEFAULT_STAGE_1_NAME,
    val stage2Name: String = DEFAULT_STAGE_2_NAME,
    val currentStage: Int = 1,
    val wires: List<WireLineSpec> = emptyList(),
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val archivedAt: Long? = null
) {
    val totalColorsCount: Int
        get() = wires.sumOf { it.colors.size }

    val totalMeters: Double
        get() = wires.sumOf { it.totalMeters }

    val stage1CompletedCount: Int
        get() = wires.sumOf { wire -> wire.colors.count { it.stage1Done } }

    val stage2CompletedCount: Int
        get() = wires.sumOf { wire -> wire.colors.count { it.stage2Done } }

    val isStage1Complete: Boolean
        get() = totalColorsCount > 0 && stage1CompletedCount == totalColorsCount

    val isStage2Complete: Boolean
        get() = totalColorsCount > 0 && stage2CompletedCount == totalColorsCount

    val isReadyToArchive: Boolean
        get() = when (stageMode) {
            OrderStageMode.SINGLE_STAGE -> isStage1Complete
            OrderStageMode.TWO_STAGE -> currentStage == 2 && isStage1Complete && isStage2Complete
        }

    val activeStageCompletedCount: Int
        get() = if (stageMode == OrderStageMode.TWO_STAGE && currentStage == 2) {
            stage2CompletedCount
        } else {
            stage1CompletedCount
        }

    companion object {
        const val DEFAULT_STAGE_1_NAME = "السحب والعزل الداخلي"
        const val DEFAULT_STAGE_2_NAME = "التجميع والتلبيس الخارجي"
    }
}

data class CalculatorState(
    val copperDiameterStr: String = "1.78",
    val outerDiameterStr: String = "3.40",
    val plasticDensityStr: String = "1.40",
    val copperDensityStr: String = "8.96",
    val lengthStr: String = "1000",
    val lengthUnit: LengthUnit = LengthUnit.METERS,
    val coresStr: String = "1",
    val selectedPlasticPresetLabel: String = "PVC 1.40"
)

data class CalculatorResults(
    val copperDiameterMm: Double,
    val outerDiameterMm: Double,
    val plasticDensity: Double,
    val copperDensity: Double,
    val lengthMeters: Double,
    val coresCount: Int,
    val isDiameterError: Boolean,
    val isValid: Boolean,
    val insulationThicknessMm: Double,
    val copperAreaMm2: Double,
    val plasticAreaMm2: Double,
    val copperGramsPerMeter: Double,
    val plasticGramsPerMeter: Double,
    val totalGramsPerMeter: Double,
    val copperKg: Double,
    val plasticKg: Double,
    val totalKg: Double
) {
    companion object {
        fun compute(
            d: Double,
            D: Double,
            plasticDensity: Double,
            copperDensity: Double,
            lengthInput: Double,
            lengthUnit: LengthUnit,
            cores: Int
        ): CalculatorResults {
            val safeCores = cores.coerceAtLeast(1)
            val lengthMeters = if (lengthUnit == LengthUnit.KILOMETERS) {
                lengthInput * 1000.0
            } else {
                lengthInput
            }
            val diameterError = d > 0.0 && D > 0.0 && D <= d
            val valid = d > 0.0 && D > d && plasticDensity > 0.0 && copperDensity > 0.0 && lengthMeters > 0.0
            if (!valid) {
                return CalculatorResults(
                    copperDiameterMm = d.coerceAtLeast(0.0),
                    outerDiameterMm = D.coerceAtLeast(0.0),
                    plasticDensity = plasticDensity.coerceAtLeast(0.0),
                    copperDensity = copperDensity.coerceAtLeast(0.0),
                    lengthMeters = lengthMeters.coerceAtLeast(0.0),
                    coresCount = safeCores,
                    isDiameterError = diameterError,
                    isValid = false,
                    insulationThicknessMm = 0.0,
                    copperAreaMm2 = 0.0,
                    plasticAreaMm2 = 0.0,
                    copperGramsPerMeter = 0.0,
                    plasticGramsPerMeter = 0.0,
                    totalGramsPerMeter = 0.0,
                    copperKg = 0.0,
                    plasticKg = 0.0,
                    totalKg = 0.0
                )
            }
            val rCu = d / 2.0
            val rOut = D / 2.0
            val thickness = (D - d) / 2.0
            val areaCu = PI * rCu.pow(2)
            val areaPl = PI * (rOut.pow(2) - rCu.pow(2))
            val cuGm = areaCu * copperDensity * safeCores
            val plGm = areaPl * plasticDensity * safeCores
            val totalGm = cuGm + plGm
            val cuKg = (cuGm * lengthMeters) / 1000.0
            val plKg = (plGm * lengthMeters) / 1000.0
            return CalculatorResults(
                copperDiameterMm = d,
                outerDiameterMm = D,
                plasticDensity = plasticDensity,
                copperDensity = copperDensity,
                lengthMeters = lengthMeters,
                coresCount = safeCores,
                isDiameterError = false,
                isValid = true,
                insulationThicknessMm = thickness,
                copperAreaMm2 = areaCu,
                plasticAreaMm2 = areaPl,
                copperGramsPerMeter = cuGm,
                plasticGramsPerMeter = plGm,
                totalGramsPerMeter = totalGm,
                copperKg = cuKg,
                plasticKg = plKg,
                totalKg = cuKg + plKg
            )
        }
    }
}

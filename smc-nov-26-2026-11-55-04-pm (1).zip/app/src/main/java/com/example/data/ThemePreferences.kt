package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.smcDataStore: DataStore<Preferences> by preferencesDataStore(name = "smc_cables_prefs")

class ThemePreferences(private val context: Context) {
    private val isDarkThemeKey = booleanPreferencesKey("is_dark_theme")
    private val isSeededKey = booleanPreferencesKey("is_seeded_v1")

    val isDarkTheme: Flow<Boolean> = context.smcDataStore.data.map { prefs ->
        prefs[isDarkThemeKey] ?: true
    }

    val isSeeded: Flow<Boolean> = context.smcDataStore.data.map { prefs ->
        prefs[isSeededKey] ?: false
    }

    suspend fun setDarkTheme(isDark: Boolean) {
        context.smcDataStore.edit { prefs ->
            prefs[isDarkThemeKey] = isDark
        }
    }

    suspend fun markSeeded() {
        context.smcDataStore.edit { prefs ->
            prefs[isSeededKey] = true
        }
    }
}

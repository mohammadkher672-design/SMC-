package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Factory
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.Factory
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.SmcTheme
import com.example.util.Formatters
import com.example.viewmodel.AppTab
import com.example.viewmodel.ToastMessage
import com.example.viewmodel.ToastTone

@Composable
fun SmcTopBar(
    copperKg: Double,
    totalPlasticKg: Double,
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit,
    onQuickInventoryClick: () -> Unit
) {
    val colors = SmcTheme.colors
    Surface(
        color = colors.surface,
        tonalElevation = 2.dp,
        shadowElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_smc_brand),
                        contentDescription = stringResource(R.string.app_name),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(11.dp))
                            .border(1.dp, colors.copper.copy(alpha = 0.45f), RoundedCornerShape(11.dp))
                    )
                    Column {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.titleLarge,
                            color = colors.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "نظام إدارة معمل الكابلات الكهربائية",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                IconButton(
                    onClick = onToggleTheme,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(colors.card)
                        .border(1.dp, colors.border, CircleShape)
                        .testTag("theme_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isDarkTheme) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                        contentDescription = stringResource(R.string.toggle_theme_cd),
                        tint = colors.copper
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickStockPill(
                    label = "النحاس الخام",
                    value = Formatters.formatKgCompact(copperKg),
                    accentColor = colors.copper,
                    containerColor = colors.copperContainer,
                    onClick = onQuickInventoryClick,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("topbar_copper_pill")
                )
                QuickStockPill(
                    label = "إجمالي البلاستيك",
                    value = Formatters.formatKgCompact(totalPlasticKg),
                    accentColor = colors.plastic,
                    containerColor = colors.plasticContainer,
                    onClick = onQuickInventoryClick,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("topbar_plastic_pill")
                )
            }
        }
        HorizontalDivider(color = colors.border, thickness = 1.dp)
    }
}

@Composable
private fun QuickStockPill(
    label: String,
    value: String,
    accentColor: Color,
    containerColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = SmcTheme.colors
    Surface(
        color = containerColor.copy(alpha = if (colors.isDark) 0.72f else 0.85f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.35f)),
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(accentColor)
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                text = value,
                style = MaterialTheme.typography.labelLarge,
                color = accentColor,
                maxLines = 1
            )
        }
    }
}

@Composable
fun SmcBottomBar(
    currentTab: AppTab,
    activeOrdersCount: Int,
    archivedOrdersCount: Int,
    onSelectTab: (AppTab) -> Unit
) {
    val colors = SmcTheme.colors
    Surface(
        color = colors.surface,
        tonalElevation = 4.dp,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            HorizontalDivider(color = colors.border, thickness = 1.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                AppTab.entries.forEach { tab ->
                    val selected = tab == currentTab
                    val icon = when (tab) {
                        AppTab.ORDERS -> if (selected) Icons.Filled.Factory else Icons.Outlined.Factory
                        AppTab.INVENTORY -> if (selected) Icons.Filled.Inventory2 else Icons.Outlined.Inventory2
                        AppTab.CALCULATOR -> if (selected) Icons.Filled.Calculate else Icons.Outlined.Calculate
                        AppTab.ARCHIVE -> if (selected) Icons.Filled.Archive else Icons.Outlined.Archive
                    }
                    val badgeCount = when (tab) {
                        AppTab.ORDERS -> activeOrdersCount
                        AppTab.ARCHIVE -> archivedOrdersCount
                        else -> 0
                    }
                    val activeTint = when (tab) {
                        AppTab.ORDERS -> colors.copper
                        AppTab.INVENTORY -> colors.plastic
                        AppTab.CALCULATOR -> colors.copper
                        AppTab.ARCHIVE -> colors.emerald
                    }
                    val pillBg = when (tab) {
                        AppTab.ORDERS -> colors.copperContainer
                        AppTab.INVENTORY -> colors.plasticContainer
                        AppTab.CALCULATOR -> colors.copperContainer
                        AppTab.ARCHIVE -> colors.emeraldContainer
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onSelectTab(tab) }
                            .padding(vertical = 4.dp)
                            .testTag("nav_tab_${tab.route}")
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (selected) pillBg else Color.Transparent)
                                .padding(horizontal = 16.dp, vertical = 5.dp)
                        ) {
                            BadgedBox(
                                badge = {
                                    if (badgeCount > 0) {
                                        Badge(
                                            containerColor = if (selected) activeTint else colors.border,
                                            contentColor = if (selected) Color.White else colors.textPrimary
                                        ) {
                                            Text(
                                                text = if (badgeCount > 99) "99+" else badgeCount.toString(),
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = tab.labelAr,
                                    tint = if (selected) activeTint else colors.textSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = tab.labelAr,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = if (selected) activeTint else colors.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SmcToastBanner(
    toast: ToastMessage?,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = SmcTheme.colors
    AnimatedVisibility(
        visible = toast != null,
        enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
        modifier = modifier
    ) {
        toast?.let { message ->
            val accent = when (message.tone) {
                ToastTone.SUCCESS -> colors.emerald
                ToastTone.INFO -> colors.plastic
                ToastTone.ERROR -> colors.danger
            }
            val icon = when (message.tone) {
                ToastTone.SUCCESS -> Icons.Filled.CheckCircle
                ToastTone.INFO -> Icons.Filled.Info
                ToastTone.ERROR -> Icons.Filled.ErrorOutline
            }
            Surface(
                color = colors.cardElevated,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, accent.copy(alpha = 0.65f)),
                shadowElevation = 8.dp,
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .fillMaxWidth()
                    .clickable(onClick = onDismiss)
                    .testTag("smc_toast_banner")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = message.text,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.textPrimary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
fun SmcConfirmDialog(
    title: String,
    message: String,
    confirmText: String = "تأكيد",
    isDestructive: Boolean = true,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SmcTheme.colors
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.card,
        titleContentColor = colors.textPrimary,
        textContentColor = colors.textSecondary,
        shape = RoundedCornerShape(20.dp),
        title = {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = colors.textPrimary
            )
        },
        text = {
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isDestructive) colors.danger else colors.emerald,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("confirm_dialog_ok_button")
            ) {
                Text(confirmText, style = MaterialTheme.typography.labelLarge)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                border = BorderStroke(1.dp, colors.border),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("confirm_dialog_cancel_button")
            ) {
                Text("إلغاء", color = colors.textSecondary, style = MaterialTheme.typography.labelLarge)
            }
        }
    )
}

@Composable
fun ColorSwatchDot(
    colorArgb: Long,
    isDualGround: Boolean = false,
    size: Dp = 18.dp,
    modifier: Modifier = Modifier
) {
    val borderColor = SmcTheme.colors.border
    Canvas(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .border(1.dp, borderColor, CircleShape)
    ) {
        if (isDualGround) {
            val circlePath = Path().apply {
                addOval(androidx.compose.ui.geometry.Rect(0f, 0f, this@Canvas.size.width, this@Canvas.size.height))
            }
            clipPath(circlePath) {
                drawRect(color = Color(0xFFEAB308))
                val stripePath = Path().apply {
                    moveTo(0f, this@Canvas.size.height)
                    lineTo(this@Canvas.size.width, 0f)
                    lineTo(this@Canvas.size.width, this@Canvas.size.height)
                    close()
                }
                drawPath(stripePath, color = Color(0xFF16A34A))
            }
        } else {
            drawCircle(color = Color(colorArgb))
            // Subtle glossy sheen
            drawCircle(
                brush = Brush.linearGradient(
                    colors = listOf(Color.White.copy(alpha = 0.28f), Color.Transparent),
                    start = Offset(0f, 0f),
                    end = Offset(this.size.width, this.size.height)
                )
            )
        }
    }
}

@Composable
fun PresetComboField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    presets: List<String>,
    placeholder: String = "",
    testTagPrefix: String,
    modifier: Modifier = Modifier
) {
    val colors = SmcTheme.colors
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label) },
            placeholder = if (placeholder.isNotEmpty()) {
                { Text(placeholder, color = colors.textSecondary.copy(alpha = 0.6f)) }
            } else null,
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            trailingIcon = {
                if (presets.isNotEmpty()) {
                    IconButton(
                        onClick = { expanded = !expanded },
                        modifier = Modifier.testTag("${testTagPrefix}_dropdown_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.KeyboardArrowDown,
                            contentDescription = "اختر من المحفوظ",
                            tint = colors.copper
                        )
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = colors.copper,
                unfocusedBorderColor = colors.border,
                focusedLabelColor = colors.copper,
                unfocusedLabelColor = colors.textSecondary,
                focusedTextColor = colors.textPrimary,
                unfocusedTextColor = colors.textPrimary,
                focusedContainerColor = colors.surface,
                unfocusedContainerColor = colors.surface
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("${testTagPrefix}_input")
        )

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            containerColor = colors.cardElevated,
            modifier = Modifier.fillMaxWidth(0.78f)
        ) {
            presets.forEach { preset ->
                DropdownMenuItem(
                    text = {
                        Text(
                            text = preset,
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.textPrimary
                        )
                    },
                    onClick = {
                        onValueChange(preset)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    trailing: @Composable (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val colors = SmcTheme.colors
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = colors.textPrimary
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
            }
        }
        if (trailing != null) {
            Spacer(modifier = Modifier.width(8.dp))
            trailing()
        }
    }
}

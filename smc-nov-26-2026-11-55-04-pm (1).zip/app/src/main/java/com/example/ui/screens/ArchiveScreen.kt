package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.FactoryOrder
import com.example.data.OrderStageMode
import com.example.ui.components.ColorSwatchDot
import com.example.ui.components.SectionHeader
import com.example.ui.components.SmcConfirmDialog
import com.example.ui.theme.SmcTheme
import com.example.util.Formatters

@Composable
fun ArchiveScreen(
    archivedOrders: List<FactoryOrder>,
    onRestoreOrder: (Long) -> Unit,
    onDeletePermanently: (Long) -> Unit
) {
    val colors = SmcTheme.colors
    var searchQuery by remember { mutableStateOf("") }
    var deletingOrder by remember { mutableStateOf<FactoryOrder?>(null) }

    val filteredOrders = remember(archivedOrders, searchQuery) {
        val q = searchQuery.trim()
        if (q.isEmpty()) {
            archivedOrders
        } else {
            archivedOrders.filter { order ->
                order.orderNumber.contains(q, ignoreCase = true) ||
                    order.orderType.contains(q, ignoreCase = true) ||
                    order.insulationDetails.contains(q, ignoreCase = true)
            }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("archive_screen_list")
    ) {
        item(key = "archive_header") {
            SectionHeader(
                title = "أرشيف الأوردرات المنجزة (${archivedOrders.size})",
                subtitle = "سجل الأوامر المكتملة مع إمكانية البحث والاستعادة للتشغيل"
            )
        }

        // Search Bar
        item(key = "archive_search") {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text(
                        "ابحث برقم الأوردر أو نوعه...",
                        color = colors.textSecondary.copy(alpha = 0.7f)
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = "بحث",
                        tint = colors.emerald
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "مسح البحث",
                                tint = colors.textSecondary
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = colors.emerald,
                    unfocusedBorderColor = colors.border,
                    focusedTextColor = colors.textPrimary,
                    unfocusedTextColor = colors.textPrimary,
                    focusedContainerColor = colors.card,
                    unfocusedContainerColor = colors.card
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("archive_search_input")
            )
        }

        if (filteredOrders.isEmpty()) {
            item(key = "archive_empty") {
                Surface(
                    color = colors.card,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, colors.border),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 36.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(58.dp)
                                .clip(CircleShape)
                                .background(colors.emeraldContainer)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Archive,
                                contentDescription = null,
                                tint = colors.emerald,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Text(
                            text = if (searchQuery.isNotBlank()) "لا توجد نتائج مطابقة للبحث" else "الأرشيف فارغ حالياً",
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.textPrimary
                        )
                        Text(
                            text = if (searchQuery.isNotBlank()) {
                                "جرّب البحث برقم أوردر آخر أو امسح مربع البحث."
                            } else {
                                "عند إتمام جميع بنود أي أوردر نشط والضغط على «نقل إلى الأرشيف» سيظهر هنا بكامل تفاصيله."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                }
            }
        } else {
            items(filteredOrders, key = { it.id }) { order ->
                ArchivedOrderCard(
                    order = order,
                    onRestore = { onRestoreOrder(order.id) },
                    onDeletePermanently = { deletingOrder = order }
                )
            }
        }

        item(key = "archive_bottom_spacer") {
            Spacer(modifier = Modifier.height(12.dp))
        }
    }

    deletingOrder?.let { target ->
        SmcConfirmDialog(
            title = "تأكيد الحذف النهائي",
            message = "هل أنت متأكد من حذف الأوردر المؤرشف «${target.orderNumber}» نهائياً؟ لن يمكن استعادته لاحقاً.",
            confirmText = "حذف نهائي",
            isDestructive = true,
            onConfirm = {
                onDeletePermanently(target.id)
                deletingOrder = null
            },
            onDismiss = { deletingOrder = null }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ArchivedOrderCard(
    order: FactoryOrder,
    onRestore: () -> Unit,
    onDeletePermanently: () -> Unit
) {
    val colors = SmcTheme.colors

    Surface(
        color = colors.card,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, colors.emerald.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("archived_order_card_${order.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = colors.emeraldContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = order.orderNumber,
                            style = MaterialTheme.typography.labelLarge,
                            color = colors.emerald,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Surface(
                        color = colors.surface,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (order.stageMode == OrderStageMode.TWO_STAGE) {
                                "مرحلتين (${order.stage1Name} ➔ ${order.stage2Name})"
                            } else {
                                "مرحلة واحدة"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textSecondary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Text(
                text = order.orderType,
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary
            )

            if (order.insulationDetails.isNotBlank()) {
                Text(
                    text = "تفاصيل العزل: ${order.insulationDetails}",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "الإجمالي: ${Formatters.formatDualLength(order.totalMeters)}",
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.copper
                )
                order.archivedAt?.let { archivedTs ->
                    Text(
                        text = "أُرشف: ${Formatters.formatTimestamp(archivedTs)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textSecondary
                    )
                }
            }

            HorizontalDivider(color = colors.border.copy(alpha = 0.7f))

            // Wires & Colors breakdown
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                order.wires.forEach { wire ->
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(
                            text = "سلك ${wire.wireType} — ${Formatters.formatDualLength(wire.totalMeters)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.textPrimary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            wire.colors.forEach { c ->
                                Surface(
                                    color = colors.surface,
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, colors.border.copy(alpha = 0.7f))
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        ColorSwatchDot(
                                            colorArgb = c.colorArgb,
                                            isDualGround = c.isDualGround,
                                            size = 12.dp
                                        )
                                        Text(
                                            text = "${c.colorName}: ${Formatters.formatDualLength(c.lengthMeters)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = colors.textSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider(color = colors.border.copy(alpha = 0.7f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onRestore,
                    border = BorderStroke(1.dp, colors.plastic.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(11.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("restore_order_btn_${order.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Restore,
                        contentDescription = null,
                        tint = colors.plastic,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text("استعادة للتشغيل", color = colors.plastic, style = MaterialTheme.typography.labelMedium)
                }

                OutlinedButton(
                    onClick = onDeletePermanently,
                    border = BorderStroke(1.dp, colors.danger.copy(alpha = 0.6f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = colors.danger),
                    shape = RoundedCornerShape(11.dp),
                    modifier = Modifier
                        .weight(0.85f)
                        .testTag("delete_archived_btn_${order.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeleteForever,
                        contentDescription = null,
                        tint = colors.danger,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text("حذف نهائي", color = colors.danger, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

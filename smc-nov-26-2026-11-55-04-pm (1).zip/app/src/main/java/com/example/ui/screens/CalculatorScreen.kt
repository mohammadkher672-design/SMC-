package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.CalculatorResults
import com.example.data.CalculatorState
import com.example.data.InventoryItemEntity
import com.example.data.LengthUnit
import com.example.ui.components.SectionHeader
import com.example.ui.theme.SmcTheme
import com.example.util.Formatters
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private data class DensityQuickPreset(val label: String, val value: String)

private val PlasticDensityPresets = listOf(
    DensityQuickPreset("PVC 1.40", "1.40"),
    DensityQuickPreset("PVC طري 1.35", "1.35"),
    DensityQuickPreset("XLPE 0.92", "0.92")
)

@Composable
fun CalculatorScreen(
    state: CalculatorState,
    results: CalculatorResults,
    copperBalanceKg: Double,
    plasticItems: List<InventoryItemEntity>,
    onCopperDiameterChange: (String) -> Unit,
    onOuterDiameterChange: (String) -> Unit,
    onPlasticDensityChange: (String, String) -> Unit,
    onCopperDensityChange: (String) -> Unit,
    onLengthChange: (String) -> Unit,
    onLengthUnitChange: (LengthUnit) -> Unit,
    onCoresChange: (String) -> Unit,
    onDeductFromInventory: (String, String) -> Unit
) {
    val colors = SmcTheme.colors
    var showDeductDialog by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("calculator_screen_list")
    ) {
        item(key = "calc_header") {
            SectionHeader(
                title = "حاسبة الكبل والعزل الهندسية",
                subtitle = "حساب سماكة العزل وأوزان النحاس والبلاستيك بدقة ومقارنتها بالمستودع"
            )
        }

        // Validation Alert if D <= d
        if (results.isDiameterError) {
            item(key = "calc_diameter_error") {
                Surface(
                    color = colors.dangerContainer,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.2.dp, colors.danger),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("calc_diameter_error_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ErrorOutline,
                            contentDescription = null,
                            tint = colors.danger,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "خطأ في الأقطار: القطر الخارجي D يجب أن يكون أكبر من قطر النحاس d",
                                style = MaterialTheme.typography.labelLarge,
                                color = colors.danger
                            )
                            Text(
                                text = "الرجاء تصحيح القيمتين (D > d) لإتمام الحساب الهندسي.",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textPrimary
                            )
                        }
                    }
                }
            }
        }

        // Dynamic Cross-Section Diagram Card
        item(key = "calc_cross_section_card") {
            CableCrossSectionCard(results = results)
        }

        // Inputs Card
        item(key = "calc_inputs_card") {
            Surface(
                color = colors.card,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, colors.border),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "المعطيات الهندسية",
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.copper
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CalcNumberField(
                            label = "قطر النحاس d (مم)",
                            value = state.copperDiameterStr,
                            onValueChange = onCopperDiameterChange,
                            accent = colors.copper,
                            isError = results.isDiameterError,
                            testTag = "calc_copper_d_input",
                            modifier = Modifier.weight(1f)
                        )
                        CalcNumberField(
                            label = "القطر الخارجي D (مم)",
                            value = state.outerDiameterStr,
                            onValueChange = onOuterDiameterChange,
                            accent = colors.plastic,
                            isError = results.isDiameterError,
                            testTag = "calc_outer_D_input",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Plastic Density Quick Chips
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "كثافة البلاستيك السريعة (غ/سم³):",
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.textSecondary
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            PlasticDensityPresets.forEach { preset ->
                                val selected = state.plasticDensityStr.trim() == preset.value
                                FilterChip(
                                    selected = selected,
                                    onClick = { onPlasticDensityChange(preset.value, preset.label) },
                                    label = {
                                        Text(
                                            text = preset.label,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = colors.plasticContainer,
                                        selectedLabelColor = colors.plastic,
                                        containerColor = colors.surface,
                                        labelColor = colors.textSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = selected,
                                        borderColor = colors.border,
                                        selectedBorderColor = colors.plastic
                                    ),
                                    modifier = Modifier.testTag("density_chip_${preset.value}")
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CalcNumberField(
                            label = "كثافة البلاستيك (غ/سم³)",
                            value = state.plasticDensityStr,
                            onValueChange = { onPlasticDensityChange(it, "") },
                            accent = colors.plastic,
                            testTag = "calc_plastic_density_input",
                            modifier = Modifier.weight(1f)
                        )
                        CalcNumberField(
                            label = "كثافة النحاس (غ/سم³)",
                            value = state.copperDensityStr,
                            onValueChange = onCopperDensityChange,
                            accent = colors.copper,
                            testTag = "calc_copper_density_input",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        CalcNumberField(
                            label = "طول الكبل (${state.lengthUnit.labelAr})",
                            value = state.lengthStr,
                            onValueChange = onLengthChange,
                            accent = colors.emerald,
                            testTag = "calc_length_input",
                            modifier = Modifier.weight(1.25f)
                        )
                        CalcNumberField(
                            label = "عدد الفردات",
                            value = state.coresStr,
                            onValueChange = onCoresChange,
                            accent = colors.copper,
                            keyboardType = KeyboardType.Number,
                            testTag = "calc_cores_input",
                            modifier = Modifier.weight(0.75f)
                        )
                    }

                    // Length Unit Selector (m / km)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (results.lengthMeters > 0) {
                                "الطول: ${Formatters.formatDualLength(results.lengthMeters)}"
                            } else {
                                "وحدة طول الكبل:"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.emerald
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            LengthUnit.entries.forEach { u ->
                                val selected = state.lengthUnit == u
                                Surface(
                                    color = if (selected) colors.emeraldContainer else colors.surface,
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(
                                        1.dp,
                                        if (selected) colors.emerald else colors.border
                                    ),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { onLengthUnitChange(u) }
                                        .testTag("calc_unit_${u.code}")
                                ) {
                                    Text(
                                        text = "${u.labelAr} (${u.shortAr})",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (selected) colors.emerald else colors.textSecondary,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Engineering Results Card
        if (results.isValid) {
            item(key = "calc_results_card") {
                Surface(
                    color = colors.card,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, colors.border),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("calc_results_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "النتائج الهندسية والأوزان",
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.textPrimary
                        )

                        // Geometry Metrics Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            MetricTile(
                                title = "سماكة العزل",
                                primaryValue = Formatters.formatMm(results.insulationThicknessMm),
                                secondaryValue = "(D - d) / 2",
                                accent = colors.plastic,
                                modifier = Modifier.weight(1f)
                            )
                            MetricTile(
                                title = "مساحة النحاس",
                                primaryValue = Formatters.formatArea(results.copperAreaMm2),
                                secondaryValue = "A_cu",
                                accent = colors.copper,
                                modifier = Modifier.weight(1f)
                            )
                            MetricTile(
                                title = "مساحة العزل",
                                primaryValue = Formatters.formatArea(results.plasticAreaMm2),
                                secondaryValue = "A_pl",
                                accent = colors.plastic,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        HorizontalDivider(color = colors.border.copy(alpha = 0.7f))

                        // Weights Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            WeightMetricBox(
                                title = "وزن النحاس المطلوب",
                                kgValue = Formatters.formatKg(results.copperKg),
                                perMeterValue = Formatters.formatGramsPerMeter(results.copperGramsPerMeter),
                                accent = colors.copper,
                                container = colors.copperContainer,
                                modifier = Modifier.weight(1f)
                            )
                            WeightMetricBox(
                                title = "وزن البلاستيك المطلوب",
                                kgValue = Formatters.formatKg(results.plasticKg),
                                perMeterValue = Formatters.formatGramsPerMeter(results.plasticGramsPerMeter),
                                accent = colors.plastic,
                                container = colors.plasticContainer,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Grand Total Weight Banner
                        Surface(
                            color = colors.emeraldContainer.copy(alpha = 0.75f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, colors.emerald.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "الوزن الإجمالي للكبل",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = colors.textPrimary
                                    )
                                    Text(
                                        text = Formatters.formatGramsPerMeter(results.totalGramsPerMeter),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = colors.textSecondary
                                    )
                                }
                                Text(
                                    text = Formatters.formatKg(results.totalKg),
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = colors.emerald
                                )
                            }
                        }
                    }
                }
            }

            // Live Inventory Comparison & Deduct CTA
            item(key = "calc_inventory_comparison_card") {
                Surface(
                    color = colors.card,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, colors.border),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "مقارنة تلقائية مع رصيد المستودع",
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.textPrimary
                        )

                        StockComparisonRow(
                            label = "النحاس الخام",
                            neededKg = results.copperKg,
                            availableKg = copperBalanceKg
                        )

                        HorizontalDivider(color = colors.border.copy(alpha = 0.5f))

                        plasticItems.forEach { plastic ->
                            StockComparisonRow(
                                label = plastic.name,
                                neededKg = results.plasticKg,
                                availableKg = plastic.quantityKg
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Button(
                            onClick = { showDeductDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = colors.copperAccent,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(vertical = 13.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("calc_deduct_inventory_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.RemoveCircleOutline,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "خصم الكمية من المخزون",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }

        item(key = "calc_bottom_spacer") {
            Spacer(modifier = Modifier.height(12.dp))
        }
    }

    if (showDeductDialog && results.isValid) {
        DeductCalculatorModal(
            results = results,
            copperBalanceKg = copperBalanceKg,
            plasticItems = plasticItems,
            onConfirm = { selectedPlasticId, note ->
                onDeductFromInventory(selectedPlasticId, note)
                showDeductDialog = false
            },
            onDismiss = { showDeductDialog = false }
        )
    }
}

@Composable
private fun CableCrossSectionCard(results: CalculatorResults) {
    val colors = SmcTheme.colors
    val copperColor = colors.copper
    val copperDeep = colors.copperAccent
    val plasticColor = colors.plastic
    val dangerColor = colors.danger
    val borderColor = colors.border
    val bgColor = colors.surface

    Surface(
        color = colors.card,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, if (results.isDiameterError) colors.danger else colors.border),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "المقطع العرضي للكبل (رسم حي)",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textPrimary
                )
                Surface(
                    color = if (results.isValid) colors.copperContainer else colors.dangerContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (results.isValid) {
                            "${results.coresCount} فردة  •  سماكة ${Formatters.formatMm(results.insulationThicknessMm)}"
                        } else {
                            "أبعاد غير صالحة"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (results.isValid) colors.copper else colors.danger,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(176.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(bgColor)
                    .border(1.dp, borderColor.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                ) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val maxRadius = min(size.width, size.height) * 0.44f

                    // Subtle Engineering Grid Crosshair
                    val dashEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                    drawLine(
                        color = borderColor.copy(alpha = 0.5f),
                        start = Offset(0f, center.y),
                        end = Offset(size.width, center.y),
                        strokeWidth = 1.2f,
                        pathEffect = dashEffect
                    )
                    drawLine(
                        color = borderColor.copy(alpha = 0.5f),
                        start = Offset(center.x, 0f),
                        end = Offset(center.x, size.height),
                        strokeWidth = 1.2f,
                        pathEffect = dashEffect
                    )

                    if (!results.isValid) {
                        drawCircle(
                            color = dangerColor.copy(alpha = 0.25f),
                            radius = maxRadius,
                            center = center
                        )
                        drawCircle(
                            color = dangerColor,
                            radius = maxRadius,
                            center = center,
                            style = Stroke(width = 3f)
                        )
                        return@Canvas
                    }

                    val ratio = (results.copperDiameterMm / results.outerDiameterMm)
                        .toFloat()
                        .coerceIn(0.14f, 0.90f)
                    val outerR = maxRadius
                    val innerR = maxRadius * ratio

                    // Outer Insulation Ring (Plastic)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                plasticColor.copy(alpha = 0.35f),
                                plasticColor.copy(alpha = 0.65f)
                            ),
                            center = center,
                            radius = outerR
                        ),
                        radius = outerR,
                        center = center
                    )
                    drawCircle(
                        color = plasticColor,
                        radius = outerR,
                        center = center,
                        style = Stroke(width = 3.5f)
                    )

                    // Copper Core
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFFF6C485),
                                copperColor,
                                copperDeep
                            ),
                            center = Offset(center.x - innerR * 0.22f, center.y - innerR * 0.22f),
                            radius = innerR * 1.2f
                        ),
                        radius = innerR,
                        center = center
                    )

                    // Stranded copper inner rings texture
                    if (innerR > 16f) {
                        val strandR = innerR * 0.26f
                        val orbitR = innerR * 0.54f
                        drawCircle(
                            color = Color(0xFF8C4A08).copy(alpha = 0.35f),
                            radius = strandR,
                            center = center,
                            style = Stroke(width = 1.5f)
                        )
                        for (i in 0 until 6) {
                            val angle = Math.toRadians(i * 60.0)
                            val sx = center.x + (orbitR * cos(angle)).toFloat()
                            val sy = center.y + (orbitR * sin(angle)).toFloat()
                            drawCircle(
                                color = Color(0xFF8C4A08).copy(alpha = 0.35f),
                                radius = strandR,
                                center = Offset(sx, sy),
                                style = Stroke(width = 1.5f)
                            )
                        }
                    }

                    drawCircle(
                        color = copperDeep,
                        radius = innerR,
                        center = center,
                        style = Stroke(width = 2.5f)
                    )

                    // Dimension Bracket Lines for D (Outer) and d (Copper)
                    val topY = center.y - outerR
                    drawLine(
                        color = plasticColor,
                        start = Offset(center.x - outerR, topY - 8f),
                        end = Offset(center.x + outerR, topY - 8f),
                        strokeWidth = 2.5f
                    )
                    val bottomY = center.y + innerR
                    drawLine(
                        color = copperColor,
                        start = Offset(center.x - innerR, center.y + outerR + 8f),
                        end = Offset(center.x + innerR, center.y + outerR + 8f),
                        strokeWidth = 2.5f
                    )
                }
            }

            // Legend Chips under Canvas
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(colors.copper)
                    )
                    Text(
                        text = "النحاس d = ${Formatters.formatMm(results.copperDiameterMm)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textSecondary
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(colors.plastic)
                    )
                    Text(
                        text = "الخارجي D = ${Formatters.formatMm(results.outerDiameterMm)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun CalcNumberField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    accent: Color,
    isError: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Decimal,
    testTag: String,
    modifier: Modifier = Modifier
) {
    val colors = SmcTheme.colors
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
        singleLine = true,
        isError = isError,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = if (isError) colors.danger else accent,
            unfocusedBorderColor = if (isError) colors.danger else colors.border,
            focusedLabelColor = if (isError) colors.danger else accent,
            unfocusedLabelColor = colors.textSecondary,
            focusedTextColor = colors.textPrimary,
            unfocusedTextColor = colors.textPrimary,
            focusedContainerColor = colors.surface,
            unfocusedContainerColor = colors.surface
        ),
        modifier = modifier.testTag(testTag)
    )
}

@Composable
private fun MetricTile(
    title: String,
    primaryValue: String,
    secondaryValue: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val colors = SmcTheme.colors
    Surface(
        color = colors.surface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, colors.border),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = colors.textSecondary
            )
            Text(
                text = primaryValue,
                style = MaterialTheme.typography.titleSmall,
                color = accent,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = secondaryValue,
                style = MaterialTheme.typography.labelSmall,
                color = colors.textSecondary.copy(alpha = 0.7f)
            )
        }
    }
}

@Composable
private fun WeightMetricBox(
    title: String,
    kgValue: String,
    perMeterValue: String,
    accent: Color,
    container: Color,
    modifier: Modifier = Modifier
) {
    val colors = SmcTheme.colors
    Surface(
        color = container.copy(alpha = if (colors.isDark) 0.75f else 0.9f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = colors.textSecondary
            )
            Text(
                text = kgValue,
                style = MaterialTheme.typography.titleLarge,
                color = accent
            )
            Text(
                text = perMeterValue,
                style = MaterialTheme.typography.labelSmall,
                color = colors.textPrimary.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
private fun StockComparisonRow(
    label: String,
    neededKg: Double,
    availableKg: Double
) {
    val colors = SmcTheme.colors
    val sufficient = availableKg >= neededKg
    val diff = availableKg - neededKg

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = if (sufficient) Icons.Filled.CheckCircle else Icons.Filled.WarningAmber,
                contentDescription = null,
                tint = if (sufficient) colors.emerald else colors.warning,
                modifier = Modifier.size(18.dp)
            )
            Column {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary
                )
                Text(
                    text = "المتوفر: ${Formatters.formatKg(availableKg)}  •  المطلوب: ${Formatters.formatKg(neededKg)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textSecondary
                )
            }
        }
        Surface(
            color = if (sufficient) colors.emeraldContainer else colors.warningContainer,
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = if (sufficient) {
                    "متوفر"
                } else {
                    "عجز ${Formatters.formatKg(-diff)}"
                },
                style = MaterialTheme.typography.labelSmall,
                color = if (sufficient) colors.emerald else colors.warning,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun DeductCalculatorModal(
    results: CalculatorResults,
    copperBalanceKg: Double,
    plasticItems: List<InventoryItemEntity>,
    onConfirm: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SmcTheme.colors
    var selectedPlasticId by remember {
        mutableStateOf(plasticItems.firstOrNull()?.id ?: "")
    }
    var noteInput by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            color = colors.card,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, colors.border),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("deduct_calculator_modal")
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "خصم الكمية المحسوبة من المخزون",
                    style = MaterialTheme.typography.titleLarge,
                    color = colors.textPrimary
                )

                Surface(
                    color = colors.surface,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, colors.border)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "سيتم خصم النحاس: ${Formatters.formatKg(results.copperKg)} (المتوفر: ${Formatters.formatKg(copperBalanceKg)})",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.copper
                        )
                        Text(
                            text = "سيتم خصم البلاستيك: ${Formatters.formatKg(results.plasticKg)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.plastic
                        )
                    }
                }

                Text(
                    text = "اختر نوع البلاستيك المراد الخصم منه:",
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.textPrimary
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    plasticItems.forEach { plastic ->
                        val selected = plastic.id == selectedPlasticId
                        val enough = plastic.quantityKg >= results.plasticKg
                        Surface(
                            color = if (selected) colors.plasticContainer else colors.surface,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, if (selected) colors.plastic else colors.border),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { selectedPlasticId = plastic.id }
                                .testTag("deduct_plastic_option_${plastic.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selected,
                                    onClick = { selectedPlasticId = plastic.id },
                                    colors = RadioButtonDefaults.colors(selectedColor = colors.plastic)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = plastic.name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = colors.textPrimary
                                    )
                                    Text(
                                        text = "الرصيد الحالي: ${Formatters.formatKg(plastic.quantityKg)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (enough) colors.emerald else colors.warning
                                    )
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = noteInput,
                    onValueChange = { noteInput = it },
                    label = { Text("ملاحظة إضافية (اختياري)") },
                    placeholder = { Text("مثال: أوردر رقم SMC-108") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.copper,
                        unfocusedBorderColor = colors.border,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        border = BorderStroke(1.dp, colors.border)
                    ) {
                        Text("إلغاء", color = colors.textSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (selectedPlasticId.isNotEmpty()) {
                                onConfirm(selectedPlasticId, noteInput)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = colors.copperAccent,
                            contentColor = Color.White
                        ),
                        modifier = Modifier.testTag("confirm_calc_deduct_btn")
                    ) {
                        Text("تأكيد الخصم")
                    }
                }
            }
        }
    }
}

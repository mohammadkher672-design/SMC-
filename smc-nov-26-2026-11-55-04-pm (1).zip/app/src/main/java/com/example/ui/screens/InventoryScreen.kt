package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.InventoryItemEntity
import com.example.data.InventoryLogEntity
import com.example.ui.components.SectionHeader
import com.example.ui.components.SmcConfirmDialog
import com.example.ui.theme.SmcTheme
import com.example.util.Formatters

@Composable
fun InventoryScreen(
    copperItem: InventoryItemEntity?,
    plasticItems: List<InventoryItemEntity>,
    totalPlasticKg: Double,
    logs: List<InventoryLogEntity>,
    onSetBalance: (String, Double, String) -> Unit,
    onAdjustBalance: (String, Double, String) -> Unit,
    onRenamePlastic: (String, String) -> Unit,
    onClearLogs: () -> Unit
) {
    val colors = SmcTheme.colors
    var adjustDialogItem by remember { mutableStateOf<InventoryItemEntity?>(null) }
    var renameDialogItem by remember { mutableStateOf<InventoryItemEntity?>(null) }
    var showClearLogConfirm by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("inventory_screen_list")
    ) {
        // 1. Raw Copper Hero Card
        if (copperItem != null) {
            item(key = "copper_stock_card") {
                CopperInventoryCard(
                    item = copperItem,
                    onDirectSet = { newKg -> onSetBalance(copperItem.id, newKg, "تحديث مباشر للنحاس") },
                    onQuickDelta = { delta -> onAdjustBalance(copperItem.id, delta, "تعديل سريع للنحاس") },
                    onOpenAdjustModal = { adjustDialogItem = copperItem }
                )
            }
        }

        // 2. Total Plastic Banner
        item(key = "plastic_total_banner") {
            Surface(
                color = colors.plasticContainer.copy(alpha = if (colors.isDark) 0.75f else 0.9f),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, colors.plastic.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(colors.plastic.copy(alpha = 0.2f))
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Inventory2,
                                contentDescription = null,
                                tint = colors.plastic
                            )
                        }
                        Column {
                            Text(
                                text = "إجمالي مخزون البلاستيك",
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "مجموع الأنواع الثلاثة تلقائياً",
                                style = MaterialTheme.typography.labelSmall,
                                color = colors.textSecondary
                            )
                        }
                    }
                    Text(
                        text = Formatters.formatKg(totalPlasticKg),
                        style = MaterialTheme.typography.headlineSmall,
                        color = colors.plastic,
                        modifier = Modifier.testTag("total_plastic_kg_text")
                    )
                }
            }
        }

        // 3. Three Customizable Plastic Cards
        item(key = "plastics_header") {
            SectionHeader(
                title = "أنواع البلاستيك (3 أصناف)",
                subtitle = "يمكنك تسمية كل صنف وتعديل رصيده يدوياً أو عبر إضافة/خصم بملاحظة"
            )
        }

        items(plasticItems, key = { it.id }) { plastic ->
            PlasticInventoryCard(
                item = plastic,
                onRenameClick = { renameDialogItem = plastic },
                onDirectSet = { newKg -> onSetBalance(plastic.id, newKg, "تحديث مباشر لـ ${plastic.name}") },
                onQuickDelta = { delta -> onAdjustBalance(plastic.id, delta, "تعديل سريع لـ ${plastic.name}") },
                onOpenAdjustModal = { adjustDialogItem = plastic }
            )
        }

        // 4. Warehouse Activity Log
        item(key = "warehouse_log_header") {
            Spacer(modifier = Modifier.height(4.dp))
            SectionHeader(
                title = "سجل حركة المستودع",
                subtitle = "آخر عمليات الإضافة والخصم والتعديل",
                trailing = {
                    if (logs.isNotEmpty()) {
                        OutlinedButton(
                            onClick = { showClearLogConfirm = true },
                            border = BorderStroke(1.dp, colors.danger.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("clear_inventory_logs_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DeleteSweep,
                                contentDescription = null,
                                tint = colors.danger,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("مسح السجل", color = colors.danger, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            )
        }

        if (logs.isEmpty()) {
            item(key = "warehouse_log_empty") {
                Surface(
                    color = colors.card,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, colors.border),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.History,
                            contentDescription = null,
                            tint = colors.textSecondary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "لا توجد حركات مسجلة في المستودع بعد",
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.textSecondary
                        )
                    }
                }
            }
        } else {
            items(logs, key = { it.id }) { log ->
                WarehouseLogRow(log = log)
            }
        }

        item(key = "inventory_bottom_spacer") {
            Spacer(modifier = Modifier.height(12.dp))
        }
    }

    // Add / Deduct With Note Modal
    adjustDialogItem?.let { item ->
        StockAdjustModal(
            item = item,
            onConfirm = { delta, note ->
                onAdjustBalance(item.id, delta, note)
                adjustDialogItem = null
            },
            onDismiss = { adjustDialogItem = null }
        )
    }

    // Rename Plastic Modal
    renameDialogItem?.let { item ->
        RenamePlasticDialog(
            currentName = item.name,
            onConfirm = { newName ->
                onRenamePlastic(item.id, newName)
                renameDialogItem = null
            },
            onDismiss = { renameDialogItem = null }
        )
    }

    // Clear Log Confirmation Modal
    if (showClearLogConfirm) {
        SmcConfirmDialog(
            title = "مسح سجل حركة المستودع",
            message = "هل تريد مسح جميع سجلات حركة المستودع؟ لن تتأثر الأرصدة الحالية.",
            confirmText = "مسح السجل",
            isDestructive = true,
            onConfirm = {
                onClearLogs()
                showClearLogConfirm = false
            },
            onDismiss = { showClearLogConfirm = false }
        )
    }
}

@Composable
private fun CopperInventoryCard(
    item: InventoryItemEntity,
    onDirectSet: (Double) -> Unit,
    onQuickDelta: (Double) -> Unit,
    onOpenAdjustModal: () -> Unit
) {
    val colors = SmcTheme.colors
    var manualInput by remember(item.quantityKg) {
        mutableStateOf(Formatters.formatNumber(item.quantityKg, 2).replace(",", ""))
    }

    Surface(
        color = colors.card,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.2.dp, colors.copper.copy(alpha = 0.55f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("copper_inventory_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.titleLarge,
                        color = colors.copper
                    )
                    Text(
                        text = "الرصيد الحالي المتوفر بالكيلوغرام",
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textSecondary
                    )
                }
                Surface(
                    color = colors.copperContainer,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, colors.copper.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = Formatters.formatKg(item.quantityKg),
                        style = MaterialTheme.typography.headlineSmall,
                        color = colors.copper,
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .testTag("copper_balance_value")
                    )
                }
            }

            // Direct Manual Input Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = manualInput,
                    onValueChange = { manualInput = it },
                    label = { Text("تحديث الرصيد يدوياً (كغ)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.copper,
                        unfocusedBorderColor = colors.border,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary,
                        focusedContainerColor = colors.surface,
                        unfocusedContainerColor = colors.surface
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("copper_manual_input")
                )
                Button(
                    onClick = {
                        Formatters.parseDoubleSafe(manualInput)?.let { onDirectSet(it) }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors.copperAccent,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
                    modifier = Modifier.testTag("copper_manual_save_btn")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Save,
                        contentDescription = "تحديث",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تحديث", style = MaterialTheme.typography.labelLarge)
                }
            }

            // Quick +/- Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickDeltaButton(label = "+100", isAdd = true, accent = colors.emerald, modifier = Modifier.weight(1f)) {
                    onQuickDelta(100.0)
                }
                QuickDeltaButton(label = "+25", isAdd = true, accent = colors.emerald, modifier = Modifier.weight(1f)) {
                    onQuickDelta(25.0)
                }
                QuickDeltaButton(label = "-25", isAdd = false, accent = colors.danger, modifier = Modifier.weight(1f)) {
                    onQuickDelta(-25.0)
                }
                QuickDeltaButton(label = "-100", isAdd = false, accent = colors.danger, modifier = Modifier.weight(1f)) {
                    onQuickDelta(-100.0)
                }
            }

            // Add / Deduct With Note Button
            OutlinedButton(
                onClick = onOpenAdjustModal,
                border = BorderStroke(1.dp, colors.copper.copy(alpha = 0.55f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("copper_adjust_note_btn")
            ) {
                Icon(
                    imageVector = Icons.Filled.SwapVert,
                    contentDescription = null,
                    tint = colors.copper,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "إضافة أو خصم كمية مع ملاحظة",
                    color = colors.copper,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun PlasticInventoryCard(
    item: InventoryItemEntity,
    onRenameClick: () -> Unit,
    onDirectSet: (Double) -> Unit,
    onQuickDelta: (Double) -> Unit,
    onOpenAdjustModal: () -> Unit
) {
    val colors = SmcTheme.colors
    var manualInput by remember(item.quantityKg) {
        mutableStateOf(Formatters.formatNumber(item.quantityKg, 2).replace(",", ""))
    }

    LaunchedEffect(item.quantityKg) {
        manualInput = Formatters.formatNumber(item.quantityKg, 2).replace(",", "")
    }

    Surface(
        color = colors.card,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, colors.border),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("plastic_card_${item.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(colors.plastic)
                    )
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.textPrimary
                    )
                    IconButton(
                        onClick = onRenameClick,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("rename_plastic_btn_${item.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Edit,
                            contentDescription = "تغيير اسم البلاستيك",
                            tint = colors.plastic,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                }
                Surface(
                    color = colors.plasticContainer,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = Formatters.formatKg(item.quantityKg),
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.plastic,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = manualInput,
                    onValueChange = { manualInput = it },
                    label = { Text("الكمية اليدوية (كغ)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.plastic,
                        unfocusedBorderColor = colors.border,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary,
                        focusedContainerColor = colors.surface,
                        unfocusedContainerColor = colors.surface
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("plastic_manual_input_${item.id}")
                )
                Button(
                    onClick = {
                        Formatters.parseDoubleSafe(manualInput)?.let { onDirectSet(it) }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors.plasticAccent,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
                    modifier = Modifier.testTag("plastic_save_btn_${item.id}")
                ) {
                    Text("حفظ", style = MaterialTheme.typography.labelLarge)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                QuickDeltaButton(label = "+25", isAdd = true, accent = colors.emerald, modifier = Modifier.weight(0.8f)) {
                    onQuickDelta(25.0)
                }
                QuickDeltaButton(label = "-25", isAdd = false, accent = colors.danger, modifier = Modifier.weight(0.8f)) {
                    onQuickDelta(-25.0)
                }
                OutlinedButton(
                    onClick = onOpenAdjustModal,
                    border = BorderStroke(1.dp, colors.border),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    modifier = Modifier.weight(1.4f)
                ) {
                    Text(
                        text = "إضافة / خصم بملاحظة",
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.textPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickDeltaButton(
    label: String,
    isAdd: Boolean,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = SmcTheme.colors
    OutlinedButton(
        onClick = onClick,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
        shape = RoundedCornerShape(10.dp),
        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
        modifier = modifier
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = accent,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun WarehouseLogRow(log: InventoryLogEntity) {
    val colors = SmcTheme.colors
    val isPositive = log.deltaKg >= 0.0
    val deltaColor = if (isPositive) colors.emerald else colors.danger

    Surface(
        color = colors.card,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, colors.border.copy(alpha = 0.8f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = log.materialName,
                        style = MaterialTheme.typography.labelLarge,
                        color = colors.textPrimary
                    )
                    Surface(
                        color = colors.surface,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = log.actionLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = Formatters.formatDeltaKg(log.deltaKg),
                    style = MaterialTheme.typography.labelLarge,
                    color = deltaColor
                )
            }

            if (log.note.isNotBlank()) {
                Text(
                    text = log.note,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "الرصيد بعد العملية: ${Formatters.formatKg(log.resultingBalanceKg)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textPrimary.copy(alpha = 0.85f)
                )
                Text(
                    text = Formatters.formatTimestamp(log.timestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textSecondary
                )
            }
        }
    }
}

@Composable
private fun StockAdjustModal(
    item: InventoryItemEntity,
    onConfirm: (Double, String) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SmcTheme.colors
    var isAddMode by remember { mutableStateOf(true) }
    var amountStr by remember { mutableStateOf("") }
    var noteStr by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            color = colors.card,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, colors.border),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("stock_adjust_modal")
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "تعديل رصيد: ${item.name}",
                    style = MaterialTheme.typography.titleLarge,
                    color = colors.textPrimary
                )
                Text(
                    text = "الرصيد الحالي: ${Formatters.formatKg(item.quantityKg)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { isAddMode = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAddMode) colors.emerald else colors.surface,
                            contentColor = if (isAddMode) Color.White else colors.textSecondary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إضافة (+)", style = MaterialTheme.typography.labelLarge)
                    }
                    Button(
                        onClick = { isAddMode = false },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!isAddMode) colors.danger else colors.surface,
                            contentColor = if (!isAddMode) Color.White else colors.textSecondary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Remove, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("خصم (-)", style = MaterialTheme.typography.labelLarge)
                    }
                }

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("الكمية بالكيلوغرام (كغ)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = if (isAddMode) colors.emerald else colors.danger,
                        unfocusedBorderColor = colors.border,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("adjust_amount_input")
                )

                OutlinedTextField(
                    value = noteStr,
                    onValueChange = { noteStr = it },
                    label = { Text("ملاحظة (اختياري)") },
                    placeholder = { Text("مثال: توريد شحنة جديدة أو سحب لأوردر SMC-105") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.copper,
                        unfocusedBorderColor = colors.border,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("adjust_note_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        border = BorderStroke(1.dp, colors.border),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("إلغاء", color = colors.textSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val parsed = Formatters.parseDoubleSafe(amountStr)
                            if (parsed != null && parsed > 0.0) {
                                val signed = if (isAddMode) parsed else -parsed
                                onConfirm(signed, noteStr)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAddMode) colors.emerald else colors.danger,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("confirm_stock_adjust_btn")
                    ) {
                        Text(if (isAddMode) "تنفيذ الإضافة" else "تنفيذ الخصم")
                    }
                }
            }
        }
    }
}

@Composable
private fun RenamePlasticDialog(
    currentName: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SmcTheme.colors
    var nameInput by remember { mutableStateOf(currentName) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            color = colors.card,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, colors.border),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "تسمية نوع البلاستيك",
                    style = MaterialTheme.typography.titleLarge,
                    color = colors.textPrimary
                )
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text("الاسم الجديد") },
                    placeholder = { Text("مثال: PVC عزل أو XLPE حراري") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.plastic,
                        unfocusedBorderColor = colors.border,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("rename_plastic_input")
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        border = BorderStroke(1.dp, colors.border)
                    ) {
                        Text("إلغاء", color = colors.textSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (nameInput.isNotBlank()) onConfirm(nameInput.trim())
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = colors.plasticAccent,
                            contentColor = Color.White
                        ),
                        modifier = Modifier.testTag("confirm_rename_plastic_btn")
                    ) {
                        Text("حفظ الاسم")
                    }
                }
            }
        }
    }
}

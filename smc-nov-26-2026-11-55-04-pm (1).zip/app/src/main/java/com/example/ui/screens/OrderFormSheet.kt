package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ColorLengthItem
import com.example.data.FactoryOrder
import com.example.data.LengthUnit
import com.example.data.OrderStageMode
import com.example.data.PresetCategory
import com.example.data.PresetEntity
import com.example.data.StandardCableColors
import com.example.data.WireLineSpec
import com.example.ui.components.ColorSwatchDot
import com.example.ui.components.PresetComboField
import com.example.ui.theme.SmcTheme
import com.example.util.Formatters
import java.util.UUID

private data class EditableColorDraft(
    val id: String = UUID.randomUUID().toString(),
    val colorName: String,
    val colorArgb: Long,
    val isDualGround: Boolean = false,
    val lengthText: String = "1000",
    val unit: LengthUnit = LengthUnit.METERS,
    val stage1Done: Boolean = false,
    val stage2Done: Boolean = false
) {
    fun toMeters(): Double {
        val parsed = Formatters.parseDoubleSafe(lengthText)?.coerceAtLeast(0.0) ?: 0.0
        return if (unit == LengthUnit.KILOMETERS) parsed * 1000.0 else parsed
    }
}

private data class EditableWireDraft(
    val id: String = UUID.randomUUID().toString(),
    val wireType: String = "",
    val unit: LengthUnit = LengthUnit.METERS,
    val unifiedLength: Boolean = true,
    val unifiedLengthText: String = "1000",
    val colors: List<EditableColorDraft> = listOf(
        EditableColorDraft(
            colorName = StandardCableColors[0].name,
            colorArgb = StandardCableColors[0].colorArgb,
            lengthText = "1000",
            unit = LengthUnit.METERS
        )
    )
) {
    fun unifiedMeters(): Double {
        val parsed = Formatters.parseDoubleSafe(unifiedLengthText)?.coerceAtLeast(0.0) ?: 0.0
        return if (unit == LengthUnit.KILOMETERS) parsed * 1000.0 else parsed
    }

    fun totalMeters(): Double {
        return if (unifiedLength) {
            unifiedMeters() * colors.size
        } else {
            colors.sumOf { it.toMeters() }
        }
    }
}

private val CustomColorPaletteSwatches = listOf(
    0xFFEC4899L, // وردي
    0xFF14B8A6L, // تركوازي
    0xFF84CC16L, // ليموني
    0xFF6366F1L, // نيلي
    0xFFF97316L, // برتقالي فاتح
    0xFF78350FL, // بني داكن
    0xFF06B6D4L, // سماوي
    0xFF475569L  // أردوازي
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OrderFormDialog(
    initialOrder: FactoryOrder?,
    presets: List<PresetEntity>,
    onSave: (FactoryOrder) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SmcTheme.colors
    val isEditing = initialOrder != null

    val orderNumberPresets = remember(presets) {
        presets.filter { it.category == PresetCategory.ORDER_NUMBER.code }.map { it.value }
    }
    val orderTypePresets = remember(presets) {
        presets.filter { it.category == PresetCategory.ORDER_TYPE.code }.map { it.value }
    }
    val insulationPresets = remember(presets) {
        presets.filter { it.category == PresetCategory.INSULATION.code }.map { it.value }
    }
    val wireTypePresets = remember(presets) {
        presets.filter { it.category == PresetCategory.WIRE_TYPE.code }.map { it.value }
    }

    var orderNumber by remember { mutableStateOf(initialOrder?.orderNumber ?: "") }
    var orderType by remember { mutableStateOf(initialOrder?.orderType ?: "") }
    var insulationDetails by remember { mutableStateOf(initialOrder?.insulationDetails ?: "") }
    var stageMode by remember { mutableStateOf(initialOrder?.stageMode ?: OrderStageMode.SINGLE_STAGE) }
    var stage1Name by remember {
        mutableStateOf(initialOrder?.stage1Name ?: FactoryOrder.DEFAULT_STAGE_1_NAME)
    }
    var stage2Name by remember {
        mutableStateOf(initialOrder?.stage2Name ?: FactoryOrder.DEFAULT_STAGE_2_NAME)
    }

    val wireDrafts = remember {
        mutableStateListOf<EditableWireDraft>().apply {
            if (initialOrder != null && initialOrder.wires.isNotEmpty()) {
                initialOrder.wires.forEach { wire ->
                    val prefUnit = wire.preferredUnit
                    val firstMeters = wire.colors.firstOrNull()?.lengthMeters ?: 1000.0
                    val unifiedDisplay = if (prefUnit == LengthUnit.KILOMETERS) {
                        Formatters.formatNumber(firstMeters / 1000.0, 3).replace(",", "")
                    } else {
                        Formatters.formatNumber(firstMeters, 1).replace(",", "")
                    }
                    add(
                        EditableWireDraft(
                            id = wire.id,
                            wireType = wire.wireType,
                            unit = prefUnit,
                            unifiedLength = wire.unifiedLength,
                            unifiedLengthText = unifiedDisplay,
                            colors = wire.colors.map { c ->
                                val cUnit = if (c.lengthMeters >= 1000.0 && c.lengthMeters % 100.0 == 0.0 && prefUnit == LengthUnit.KILOMETERS) {
                                    LengthUnit.KILOMETERS
                                } else {
                                    prefUnit
                                }
                                val displayLen = if (cUnit == LengthUnit.KILOMETERS) {
                                    Formatters.formatNumber(c.lengthMeters / 1000.0, 3).replace(",", "")
                                } else {
                                    Formatters.formatNumber(c.lengthMeters, 1).replace(",", "")
                                }
                                EditableColorDraft(
                                    id = c.id,
                                    colorName = c.colorName,
                                    colorArgb = c.colorArgb,
                                    isDualGround = c.isDualGround,
                                    lengthText = displayLen,
                                    unit = cUnit,
                                    stage1Done = c.stage1Done,
                                    stage2Done = c.stage2Done
                                )
                            }
                        )
                    )
                }
            } else {
                add(EditableWireDraft())
            }
        }
    }

    var validationError by remember { mutableStateOf<String?>(null) }
    var customColorTargetWireIndex by remember { mutableStateOf<Int?>(null) }
    var customColorName by remember { mutableStateOf("") }
    var customColorSelectedArgb by remember { mutableStateOf(CustomColorPaletteSwatches.first()) }

    val grandTotalMeters = wireDrafts.sumOf { it.totalMeters() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = colors.background,
            shape = RoundedCornerShape(22.dp),
            border = BorderStroke(1.dp, colors.border),
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f)
                .testTag("order_form_dialog")
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(colors.surface)
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (isEditing) "تعديل الأوردر" else "إنشاء أوردر جديد",
                            style = MaterialTheme.typography.titleLarge,
                            color = colors.textPrimary
                        )
                        Text(
                            text = "أي قيمة جديدة تكتبها تُحفظ تلقائياً في القوائم",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textSecondary
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_order_form_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "إغلاق",
                            tint = colors.textSecondary
                        )
                    }
                }
                HorizontalDivider(color = colors.border)

                // Scrollable Form Body
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (validationError != null) {
                        Surface(
                            color = colors.dangerContainer,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, colors.danger.copy(alpha = 0.6f))
                        ) {
                            Text(
                                text = validationError!!,
                                style = MaterialTheme.typography.bodyMedium,
                                color = colors.danger,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp)
                            )
                        }
                    }

                    // Basic Order Info Card
                    Surface(
                        color = colors.card,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, colors.border)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "بيانات الأوردر الأساسية",
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.copper
                            )

                            PresetComboField(
                                label = "رقم الأوردر *",
                                value = orderNumber,
                                onValueChange = {
                                    orderNumber = it
                                    validationError = null
                                },
                                presets = orderNumberPresets,
                                placeholder = "مثال: SMC-205",
                                testTagPrefix = "order_number"
                            )

                            PresetComboField(
                                label = "نوع الأوردر *",
                                value = orderType,
                                onValueChange = {
                                    orderType = it
                                    validationError = null
                                },
                                presets = orderTypePresets,
                                placeholder = "مثال: سلك تمديدات منزلية",
                                testTagPrefix = "order_type"
                            )

                            PresetComboField(
                                label = "تفاصيل العزل",
                                value = insulationDetails,
                                onValueChange = { insulationDetails = it },
                                presets = insulationPresets,
                                placeholder = "مثال: PVC عزل قياسي 70°C",
                                testTagPrefix = "insulation_details"
                            )
                        }
                    }

                    // Production Stage Mode Card
                    Surface(
                        color = colors.card,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, colors.border)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "نظام مراحل الإنتاج",
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.copper
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OrderStageMode.entries.forEach { mode ->
                                    val selected = stageMode == mode
                                    Surface(
                                        color = if (selected) colors.copperContainer else colors.surface,
                                        shape = RoundedCornerShape(12.dp),
                                        border = BorderStroke(
                                            1.dp,
                                            if (selected) colors.copper else colors.border
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { stageMode = mode }
                                            .testTag("stage_mode_${mode.code}")
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(12.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(
                                                text = if (mode == OrderStageMode.SINGLE_STAGE) "أوردر عادي" else "أوردر مرحلتين",
                                                style = MaterialTheme.typography.labelLarge,
                                                color = if (selected) colors.copper else colors.textPrimary
                                            )
                                            Text(
                                                text = if (mode == OrderStageMode.SINGLE_STAGE) "مرحلة واحدة" else "مرحلة 1 ➔ مرحلة 2",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = colors.textSecondary
                                            )
                                        }
                                    }
                                }
                            }

                            AnimatedVisibility(visible = stageMode == OrderStageMode.TWO_STAGE) {
                                Column(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.padding(top = 4.dp)
                                ) {
                                    OutlinedTextField(
                                        value = stage1Name,
                                        onValueChange = { stage1Name = it },
                                        label = { Text("اسم المرحلة الأولى") },
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = colors.copper,
                                            unfocusedBorderColor = colors.border,
                                            focusedTextColor = colors.textPrimary,
                                            unfocusedTextColor = colors.textPrimary,
                                            focusedContainerColor = colors.surface,
                                            unfocusedContainerColor = colors.surface
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("stage1_name_input")
                                    )
                                    OutlinedTextField(
                                        value = stage2Name,
                                        onValueChange = { stage2Name = it },
                                        label = { Text("اسم المرحلة الثانية") },
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = colors.plastic,
                                            unfocusedBorderColor = colors.border,
                                            focusedTextColor = colors.textPrimary,
                                            unfocusedTextColor = colors.textPrimary,
                                            focusedContainerColor = colors.surface,
                                            unfocusedContainerColor = colors.surface
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("stage2_name_input")
                                    )
                                }
                            }
                        }
                    }

                    // Wire Lines Section
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "الأسلاك والألوان والأطوال (${wireDrafts.size})",
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.textPrimary
                        )
                        OutlinedButton(
                            onClick = { wireDrafts.add(EditableWireDraft()) },
                            border = BorderStroke(1.dp, colors.copper),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("add_wire_line_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Add,
                                contentDescription = null,
                                tint = colors.copper,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة سلك", color = colors.copper, style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    wireDrafts.forEachIndexed { index, draft ->
                        WireDraftEditorCard(
                            index = index,
                            draft = draft,
                            canRemove = wireDrafts.size > 1,
                            wireTypePresets = wireTypePresets,
                            onUpdate = { updated -> wireDrafts[index] = updated },
                            onRemove = { wireDrafts.removeAt(index) },
                            onOpenCustomColor = {
                                customColorName = ""
                                customColorSelectedArgb = CustomColorPaletteSwatches.first()
                                customColorTargetWireIndex = index
                            }
                        )
                    }
                }

                // Footer Bar
                HorizontalDivider(color = colors.border)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(colors.surface)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "إجمالي طول الأوردر:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.textSecondary
                        )
                        Text(
                            text = Formatters.formatDualLength(grandTotalMeters),
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.emerald
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            border = BorderStroke(1.dp, colors.border),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(0.38f)
                        ) {
                            Text("إلغاء", color = colors.textSecondary, style = MaterialTheme.typography.labelLarge)
                        }
                        Button(
                            onClick = {
                                if (orderNumber.isBlank()) {
                                    validationError = "يرجى إدخال رقم الأوردر."
                                    return@Button
                                }
                                if (orderType.isBlank()) {
                                    validationError = "يرجى إدخال نوع الأوردر."
                                    return@Button
                                }
                                if (wireDrafts.any { it.wireType.isBlank() }) {
                                    validationError = "يرجى تحديد نوع ومقطع كل سلك."
                                    return@Button
                                }
                                if (wireDrafts.any { it.colors.isEmpty() }) {
                                    validationError = "يرجى اختيار لون واحد على الأقل لكل سلك."
                                    return@Button
                                }

                                val builtWires = wireDrafts.map { w ->
                                    val unifiedM = w.unifiedMeters()
                                    WireLineSpec(
                                        id = w.id,
                                        wireType = w.wireType.trim(),
                                        preferredUnitCode = w.unit.code,
                                        unifiedLength = w.unifiedLength,
                                        colors = w.colors.map { c ->
                                            ColorLengthItem(
                                                id = c.id,
                                                colorName = c.colorName,
                                                colorArgb = c.colorArgb,
                                                isDualGround = c.isDualGround,
                                                lengthMeters = if (w.unifiedLength) unifiedM else c.toMeters(),
                                                stage1Done = c.stage1Done,
                                                stage2Done = c.stage2Done
                                            )
                                        }
                                    )
                                }

                                val resultOrder = FactoryOrder(
                                    id = initialOrder?.id ?: 0L,
                                    orderNumber = orderNumber.trim(),
                                    orderType = orderType.trim(),
                                    insulationDetails = insulationDetails.trim(),
                                    stageMode = stageMode,
                                    stage1Name = stage1Name.trim().ifEmpty { FactoryOrder.DEFAULT_STAGE_1_NAME },
                                    stage2Name = stage2Name.trim().ifEmpty { FactoryOrder.DEFAULT_STAGE_2_NAME },
                                    currentStage = if (stageMode == OrderStageMode.SINGLE_STAGE) 1 else (initialOrder?.currentStage ?: 1),
                                    wires = builtWires,
                                    isArchived = initialOrder?.isArchived ?: false,
                                    createdAt = initialOrder?.createdAt ?: System.currentTimeMillis(),
                                    archivedAt = initialOrder?.archivedAt
                                )
                                onSave(resultOrder)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = colors.copperAccent,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(0.62f)
                                .testTag("save_order_submit_btn")
                        ) {
                            Text(
                                text = if (isEditing) "حفظ التعديلات" else "إنشاء الأوردر",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }
    }

    // Custom Color Mini Dialog
    val targetWireIdx = customColorTargetWireIndex
    if (targetWireIdx != null && targetWireIdx in wireDrafts.indices) {
        Dialog(onDismissRequest = { customColorTargetWireIndex = null }) {
            Surface(
                color = colors.card,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, colors.border),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "إضافة لون مخصص",
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.textPrimary
                    )
                    OutlinedTextField(
                        value = customColorName,
                        onValueChange = { customColorName = it },
                        label = { Text("اسم اللون") },
                        placeholder = { Text("مثال: سماوي فاتح أو وردي") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = colors.copper,
                            unfocusedBorderColor = colors.border,
                            focusedTextColor = colors.textPrimary,
                            unfocusedTextColor = colors.textPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("custom_color_name_input")
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CustomColorPaletteSwatches.forEach { argb ->
                            val isSelected = argb == customColorSelectedArgb
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(argb))
                                    .border(
                                        width = if (isSelected) 3.dp else 1.dp,
                                        color = if (isSelected) colors.textPrimary else colors.border,
                                        shape = CircleShape
                                    )
                                    .clickable { customColorSelectedArgb = argb }
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { customColorTargetWireIndex = null },
                            border = BorderStroke(1.dp, colors.border)
                        ) {
                            Text("إلغاء", color = colors.textSecondary)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val trimmed = customColorName.trim()
                                if (trimmed.isNotEmpty()) {
                                    val w = wireDrafts[targetWireIdx]
                                    val newColor = EditableColorDraft(
                                        colorName = trimmed,
                                        colorArgb = customColorSelectedArgb,
                                        lengthText = w.unifiedLengthText,
                                        unit = w.unit
                                    )
                                    wireDrafts[targetWireIdx] = w.copy(colors = w.colors + newColor)
                                    customColorTargetWireIndex = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = colors.copperAccent,
                                contentColor = Color.White
                            ),
                            modifier = Modifier.testTag("confirm_custom_color_btn")
                        ) {
                            Text("إضافة")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WireDraftEditorCard(
    index: Int,
    draft: EditableWireDraft,
    canRemove: Boolean,
    wireTypePresets: List<String>,
    onUpdate: (EditableWireDraft) -> Unit,
    onRemove: () -> Unit,
    onOpenCustomColor: () -> Unit
) {
    val colors = SmcTheme.colors

    Surface(
        color = colors.card,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, colors.border)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = colors.plasticContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "سلك #${index + 1}",
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.plastic,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Text(
                        text = "عدد الألوان: ${draft.colors.size}",
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.textSecondary
                    )
                }
                if (canRemove) {
                    IconButton(
                        onClick = onRemove,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "حذف السلك",
                            tint = colors.danger
                        )
                    }
                }
            }

            PresetComboField(
                label = "نوع ومقطع السلك *",
                value = draft.wireType,
                onValueChange = { onUpdate(draft.copy(wireType = it)) },
                presets = wireTypePresets,
                placeholder = "مثال: 2.5 مم²",
                testTagPrefix = "wire_type_$index"
            )

            // Standard Cable Colors Palette
            Text(
                text = "اختر الألوان القياسية أو أضف لوناً مخصصاً:",
                style = MaterialTheme.typography.labelMedium,
                color = colors.textSecondary
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StandardCableColors.forEach { presetColor ->
                    val existing = draft.colors.firstOrNull { it.colorName == presetColor.name }
                    val isSelected = existing != null
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            val updatedColors = if (isSelected) {
                                draft.colors.filterNot { it.colorName == presetColor.name }
                            } else {
                                draft.colors + EditableColorDraft(
                                    colorName = presetColor.name,
                                    colorArgb = presetColor.colorArgb,
                                    isDualGround = presetColor.isDualGround,
                                    lengthText = draft.unifiedLengthText,
                                    unit = draft.unit
                                )
                            }
                            onUpdate(draft.copy(colors = updatedColors))
                        },
                        leadingIcon = {
                            ColorSwatchDot(
                                colorArgb = presetColor.colorArgb,
                                isDualGround = presetColor.isDualGround,
                                size = 14.dp
                            )
                        },
                        label = {
                            Text(
                                text = presetColor.name,
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = colors.copperContainer,
                            selectedLabelColor = colors.textPrimary,
                            containerColor = colors.surface,
                            labelColor = colors.textSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = colors.border,
                            selectedBorderColor = colors.copper
                        )
                    )
                }

                // Add Custom Color Chip
                FilterChip(
                    selected = false,
                    onClick = onOpenCustomColor,
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.Palette,
                            contentDescription = null,
                            tint = colors.plastic,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "+ لون مخصص",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.plastic
                        )
                    },
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = false,
                        borderColor = colors.plastic.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.testTag("add_custom_color_btn_$index")
                )
            }

            // Show custom colors that aren't in StandardCableColors so user can remove them
            val customOnlyColors = draft.colors.filter { c ->
                StandardCableColors.none { it.name == c.colorName }
            }
            if (customOnlyColors.isNotEmpty()) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    customOnlyColors.forEach { c ->
                        FilterChip(
                            selected = true,
                            onClick = {
                                onUpdate(draft.copy(colors = draft.colors.filterNot { it.id == c.id }))
                            },
                            leadingIcon = { ColorSwatchDot(colorArgb = c.colorArgb, size = 14.dp) },
                            trailingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.Close,
                                    contentDescription = "إزالة",
                                    modifier = Modifier.size(14.dp)
                                )
                            },
                            label = { Text(c.colorName, style = MaterialTheme.typography.labelSmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = colors.plasticContainer,
                                selectedLabelColor = colors.textPrimary
                            )
                        )
                    }
                }
            }

            HorizontalDivider(color = colors.border.copy(alpha = 0.7f))

            // Length Unit & Unified vs Per-Color Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "وحدة القياس:",
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.textSecondary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    LengthUnit.entries.forEach { u ->
                        val selected = draft.unit == u
                        Surface(
                            color = if (selected) colors.plasticContainer else colors.surface,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, if (selected) colors.plastic else colors.border),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    if (draft.unit != u) {
                                        val oldMeters = draft.unifiedMeters()
                                        val nextVal = if (u == LengthUnit.KILOMETERS) oldMeters / 1000.0 else oldMeters
                                        val formatted = Formatters.formatNumber(nextVal, 3).replace(",", "")
                                        onUpdate(draft.copy(unit = u, unifiedLengthText = formatted))
                                    }
                                }
                                .testTag("wire_unit_${index}_${u.code}")
                        ) {
                            Text(
                                text = "${u.labelAr} (${u.shortAr})",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (selected) colors.plastic else colors.textSecondary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "تخصيص طول مختلف لكل لون",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.textPrimary
                    )
                    Text(
                        text = if (draft.unifiedLength) "الطول حالياً موحد لجميع الألوان" else "يمكنك تحديد طول ووحدة مختلفة لكل لون",
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textSecondary
                    )
                }
                Switch(
                    checked = !draft.unifiedLength,
                    onCheckedChange = { customPerColor ->
                        if (customPerColor) {
                            // Copy unified length into all colors so user starts cleanly
                            val synced = draft.colors.map {
                                it.copy(lengthText = draft.unifiedLengthText, unit = draft.unit)
                            }
                            onUpdate(draft.copy(unifiedLength = false, colors = synced))
                        } else {
                            onUpdate(draft.copy(unifiedLength = true))
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = colors.copperAccent
                    ),
                    modifier = Modifier.testTag("per_color_length_switch_$index")
                )
            }

            if (draft.unifiedLength) {
                OutlinedTextField(
                    value = draft.unifiedLengthText,
                    onValueChange = { onUpdate(draft.copy(unifiedLengthText = it)) },
                    label = { Text("طول كل لون (${draft.unit.labelAr})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    supportingText = {
                        val m = draft.unifiedMeters()
                        Text(
                            text = "لكل لون: ${Formatters.formatDualLength(m)}  •  إجمالي السلك: ${Formatters.formatDualLength(draft.totalMeters())}",
                            color = colors.emerald
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.copper,
                        unfocusedBorderColor = colors.border,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary,
                        focusedContainerColor = colors.surface,
                        unfocusedContainerColor = colors.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("unified_length_input_$index")
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    draft.colors.forEachIndexed { colorIdx, c ->
                        Surface(
                            color = colors.surface,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, colors.border)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    ColorSwatchDot(
                                        colorArgb = c.colorArgb,
                                        isDualGround = c.isDualGround,
                                        size = 18.dp
                                    )
                                    Text(
                                        text = c.colorName,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = colors.textPrimary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    // Mini unit toggle per color
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        LengthUnit.entries.forEach { u ->
                                            val sel = c.unit == u
                                            Surface(
                                                color = if (sel) colors.plasticContainer else colors.card,
                                                shape = RoundedCornerShape(6.dp),
                                                border = BorderStroke(1.dp, if (sel) colors.plastic else colors.border),
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .clickable {
                                                        val updated = draft.colors.toMutableList()
                                                        updated[colorIdx] = c.copy(unit = u)
                                                        onUpdate(draft.copy(colors = updated))
                                                    }
                                            ) {
                                                Text(
                                                    text = u.shortAr,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = if (sel) colors.plastic else colors.textSecondary,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                                OutlinedTextField(
                                    value = c.lengthText,
                                    onValueChange = { newText ->
                                        val updated = draft.colors.toMutableList()
                                        updated[colorIdx] = c.copy(lengthText = newText)
                                        onUpdate(draft.copy(colors = updated))
                                    },
                                    label = { Text("الطول (${c.unit.labelAr})") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = colors.copper,
                                        unfocusedBorderColor = colors.border,
                                        focusedTextColor = colors.textPrimary,
                                        unfocusedTextColor = colors.textPrimary
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Text(
                                    text = Formatters.formatDualLength(c.toMeters()),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = colors.emerald
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

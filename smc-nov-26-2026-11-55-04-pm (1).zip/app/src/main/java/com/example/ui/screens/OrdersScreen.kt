package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Factory
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.ColorLengthItem
import com.example.data.FactoryOrder
import com.example.data.OrderStageMode
import com.example.data.PresetCategory
import com.example.data.PresetEntity
import com.example.ui.components.ColorSwatchDot
import com.example.ui.components.SmcConfirmDialog
import com.example.ui.theme.SmcTheme
import com.example.util.Formatters

@Composable
fun OrdersScreen(
    activeOrders: List<FactoryOrder>,
    presets: List<PresetEntity>,
    onAddPreset: (PresetCategory, String) -> Unit,
    onDeletePreset: (Long) -> Unit,
    onSaveOrder: (FactoryOrder) -> Unit,
    onToggleColorCheck: (Long, String, String) -> Unit,
    onAdvanceStage2: (Long) -> Unit,
    onArchiveOrder: (Long) -> Unit,
    onDeleteOrder: (Long) -> Unit
) {
    val colors = SmcTheme.colors
    var showPresetsDialog by remember { mutableStateOf(false) }
    var showOrderForm by remember { mutableStateOf(false) }
    var editingOrder by remember { mutableStateOf<FactoryOrder?>(null) }
    var deletingOrder by remember { mutableStateOf<FactoryOrder?>(null) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("orders_screen_list")
    ) {
        // Action Bar: Saved Presets Manager + New Order
        item(key = "orders_action_bar") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = {
                        editingOrder = null
                        showOrderForm = true
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors.copperAccent,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("new_order_btn")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("أوردر جديد", style = MaterialTheme.typography.labelLarge)
                }

                OutlinedButton(
                    onClick = { showPresetsDialog = true },
                    border = BorderStroke(1.dp, colors.copper.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                    modifier = Modifier.testTag("open_presets_manager_btn")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Bookmarks,
                        contentDescription = null,
                        tint = colors.copper,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "القوائم المحفوظة",
                        color = colors.copper,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }

        // Section Summary
        item(key = "orders_header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "الأوردرات قيد التصنيع (${activeOrders.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary
                )
                if (activeOrders.isNotEmpty()) {
                    val totalActiveMeters = activeOrders.sumOf { it.totalMeters }
                    Text(
                        text = Formatters.formatDualLength(totalActiveMeters),
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.plastic
                    )
                }
            }
        }

        if (activeOrders.isEmpty()) {
            item(key = "orders_empty_state") {
                Surface(
                    color = colors.card,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, colors.border),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 36.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(colors.copperContainer)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Factory,
                                contentDescription = null,
                                tint = colors.copper,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                        Text(
                            text = "لا توجد أوردرات قيد التصنيع حالياً",
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.textPrimary
                        )
                        Text(
                            text = "اضغط على «أوردر جديد» لإضافة أمر تصنيع بمرحلة واحدة أو مرحلتين، أو اضبط قوائمك السريعة من «القوائم المحفوظة».",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                }
            }
        } else {
            items(activeOrders, key = { it.id }) { order ->
                ActiveOrderCard(
                    order = order,
                    onEdit = {
                        editingOrder = order
                        showOrderForm = true
                    },
                    onDelete = { deletingOrder = order },
                    onToggleColor = { wireId, colorId ->
                        onToggleColorCheck(order.id, wireId, colorId)
                    },
                    onAdvanceStage2 = { onAdvanceStage2(order.id) },
                    onArchive = { onArchiveOrder(order.id) }
                )
            }
        }

        item(key = "orders_bottom_spacer") {
            Spacer(modifier = Modifier.height(12.dp))
        }
    }

    if (showPresetsDialog) {
        PresetsManagerDialog(
            allPresets = presets,
            onAddPreset = onAddPreset,
            onDeletePreset = onDeletePreset,
            onDismiss = { showPresetsDialog = false }
        )
    }

    if (showOrderForm) {
        OrderFormDialog(
            initialOrder = editingOrder,
            presets = presets,
            onSave = { order ->
                onSaveOrder(order)
                showOrderForm = false
                editingOrder = null
            },
            onDismiss = {
                showOrderForm = false
                editingOrder = null
            }
        )
    }

    deletingOrder?.let { target ->
        SmcConfirmDialog(
            title = "تأكيد حذف الأوردر",
            message = "هل أنت متأكد من حذف الأوردر رقم «${target.orderNumber}»؟ لا يمكن التراجع عن هذه العملية.",
            confirmText = "حذف الأوردر",
            isDestructive = true,
            onConfirm = {
                onDeleteOrder(target.id)
                deletingOrder = null
            },
            onDismiss = { deletingOrder = null }
        )
    }
}

@Composable
private fun ActiveOrderCard(
    order: FactoryOrder,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleColor: (String, String) -> Unit,
    onAdvanceStage2: () -> Unit,
    onArchive: () -> Unit
) {
    val colors = SmcTheme.colors
    val isStage2Active = order.stageMode == OrderStageMode.TWO_STAGE && order.currentStage == 2
    val progressFraction = if (order.totalColorsCount > 0) {
        order.activeStageCompletedCount.toFloat() / order.totalColorsCount.toFloat()
    } else 0f

    Surface(
        color = colors.card,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(
            width = if (order.isReadyToArchive) 1.5.dp else 1.dp,
            color = if (order.isReadyToArchive) colors.emerald else colors.border
        ),
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .testTag("active_order_card_${order.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Card Header with Edit & Delete buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = colors.copperContainer,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, colors.copper.copy(alpha = 0.45f))
                        ) {
                            Text(
                                text = order.orderNumber,
                                style = MaterialTheme.typography.labelLarge,
                                color = colors.copper,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        Surface(
                            color = if (order.stageMode == OrderStageMode.TWO_STAGE) colors.plasticContainer else colors.surface,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Layers,
                                    contentDescription = null,
                                    tint = if (order.stageMode == OrderStageMode.TWO_STAGE) colors.plastic else colors.textSecondary,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = order.stageMode.labelAr,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (order.stageMode == OrderStageMode.TWO_STAGE) colors.plastic else colors.textSecondary
                                )
                            }
                        }
                    }

                    Text(
                        text = order.orderType,
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.textPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (order.insulationDetails.isNotBlank()) {
                        Text(
                            text = "العزل: ${order.insulationDetails}",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                }

                // Edit & Delete Immediate Action Buttons
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("edit_order_btn_${order.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Edit,
                            contentDescription = "تعديل الأوردر",
                            tint = colors.plastic,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("delete_order_btn_${order.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "حذف الأوردر",
                            tint = colors.danger,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Two-Stage Visual Stepper
            if (order.stageMode == OrderStageMode.TWO_STAGE) {
                TwoStageStepper(order = order)
            }

            // Progress Bar & Dual Length Total
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val stageCaption = if (order.stageMode == OrderStageMode.TWO_STAGE) {
                        if (isStage2Active) "إنجاز المرحلة 2 (${order.stage2Name})" else "إنجاز المرحلة 1 (${order.stage1Name})"
                    } else {
                        "تقدم التصنيع"
                    }
                    Text(
                        text = "$stageCaption: ${order.activeStageCompletedCount} / ${order.totalColorsCount}",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (order.isReadyToArchive) colors.emerald else colors.textSecondary
                    )
                    Text(
                        text = Formatters.formatDualLength(order.totalMeters),
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.copper
                    )
                }

                LinearProgressIndicator(
                    progress = { progressFraction },
                    color = when {
                        order.isReadyToArchive -> colors.emerald
                        isStage2Active -> colors.plastic
                        else -> colors.copper
                    },
                    trackColor = colors.surface,
                    strokeCap = StrokeCap.Round,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                        .clip(RoundedCornerShape(4.dp))
                )
            }

            HorizontalDivider(color = colors.border.copy(alpha = 0.7f))

            // Wire Lines & Color Checklist
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                order.wires.forEach { wire ->
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "سلك: ${wire.wireType} (${wire.colors.size} ألوان)",
                                style = MaterialTheme.typography.labelLarge,
                                color = colors.textPrimary
                            )
                            Text(
                                text = Formatters.formatDualLength(wire.totalMeters),
                                style = MaterialTheme.typography.labelSmall,
                                color = colors.textSecondary
                            )
                        }

                        wire.colors.forEach { colorItem ->
                            val isChecked = if (isStage2Active) colorItem.stage2Done else colorItem.stage1Done
                            ColorChecklistRow(
                                item = colorItem,
                                isChecked = isChecked,
                                onToggle = { onToggleColor(wire.id, colorItem.id) }
                            )
                        }
                    }
                }
            }

            // Stage 1 Complete -> Explicit Confirmation Button to Advance to Stage 2
            AnimatedVisibility(
                visible = order.stageMode == OrderStageMode.TWO_STAGE &&
                    order.currentStage == 1 &&
                    order.isStage1Complete
            ) {
                Button(
                    onClick = onAdvanceStage2,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors.plasticAccent,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(vertical = 12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("advance_stage2_btn_${order.id}")
                ) {
                    Text(
                        text = "الانتقال إلى المرحلة الثانية (${order.stage2Name})",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // All Completed -> Prominent Move to Archive Button
            AnimatedVisibility(visible = order.isReadyToArchive) {
                Button(
                    onClick = onArchive,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors.emerald,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(vertical = 12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("archive_order_btn_${order.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Archive,
                        contentDescription = null,
                        modifier = Modifier.size(19.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "نقل إلى الأرشيف",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun TwoStageStepper(order: FactoryOrder) {
    val colors = SmcTheme.colors
    val s1Done = order.currentStage == 2 || order.isStage1Complete
    val s2Active = order.currentStage == 2
    val ready = order.isReadyToArchive

    Surface(
        color = colors.surface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, colors.border)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            StagePill(
                step = "1",
                title = order.stage1Name,
                isActive = order.currentStage == 1 && !s1Done,
                isCompleted = s1Done,
                activeColor = colors.copper,
                modifier = Modifier.weight(1f)
            )
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = colors.textSecondary,
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .size(14.dp)
            )
            StagePill(
                step = "2",
                title = order.stage2Name,
                isActive = s2Active && !ready,
                isCompleted = ready,
                activeColor = colors.plastic,
                modifier = Modifier.weight(1f)
            )
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = colors.textSecondary,
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .size(14.dp)
            )
            StagePill(
                step = "✓",
                title = "الأرشيف",
                isActive = false,
                isCompleted = ready,
                activeColor = colors.emerald,
                modifier = Modifier.weight(0.75f)
            )
        }
    }
}

@Composable
private fun StagePill(
    step: String,
    title: String,
    isActive: Boolean,
    isCompleted: Boolean,
    activeColor: Color,
    modifier: Modifier = Modifier
) {
    val colors = SmcTheme.colors
    val tint = when {
        isCompleted -> colors.emerald
        isActive -> activeColor
        else -> colors.textSecondary
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(
                    when {
                        isCompleted -> colors.emerald
                        isActive -> activeColor.copy(alpha = 0.2f)
                        else -> colors.card
                    }
                )
                .border(1.dp, tint, CircleShape)
        ) {
            if (isCompleted) {
                Icon(
                    imageVector = Icons.Filled.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(13.dp)
                )
            } else {
                Text(
                    text = step,
                    style = MaterialTheme.typography.labelSmall,
                    color = tint
                )
            }
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = tint,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ColorChecklistRow(
    item: ColorLengthItem,
    isChecked: Boolean,
    onToggle: () -> Unit
) {
    val colors = SmcTheme.colors
    Surface(
        color = if (isChecked) colors.emeraldContainer.copy(alpha = 0.55f) else colors.surface,
        shape = RoundedCornerShape(11.dp),
        border = BorderStroke(
            1.dp,
            if (isChecked) colors.emerald.copy(alpha = 0.55f) else colors.border.copy(alpha = 0.7f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(11.dp))
            .clickable(onClick = onToggle)
            .testTag("color_check_row_${item.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(26.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(if (isChecked) colors.emerald else colors.card)
                    .border(
                        1.5.dp,
                        if (isChecked) colors.emerald else colors.border,
                        RoundedCornerShape(7.dp)
                    )
            ) {
                if (isChecked) {
                    Icon(
                        imageVector = Icons.Filled.Check,
                        contentDescription = "مكتمل",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            ColorSwatchDot(
                colorArgb = item.colorArgb,
                isDualGround = item.isDualGround,
                size = 18.dp
            )

            Text(
                text = item.colorName,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = if (isChecked) colors.textSecondary else colors.textPrimary,
                textDecoration = if (isChecked) TextDecoration.LineThrough else TextDecoration.None,
                modifier = Modifier.weight(1f)
            )

            Text(
                text = Formatters.formatDualLength(item.lengthMeters),
                style = MaterialTheme.typography.labelMedium,
                color = if (isChecked) colors.emerald else colors.textPrimary
            )
        }
    }
}

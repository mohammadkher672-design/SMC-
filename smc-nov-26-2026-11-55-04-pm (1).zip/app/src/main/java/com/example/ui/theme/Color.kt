package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// Dark Luxury Palette (Industrial Precision)
val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF111827)
val DarkCard = Color(0xFF1E293B)
val DarkCardElevated = Color(0xFF263348)
val DarkBorder = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF1F5F9)
val DarkTextSecondary = Color(0xFF94A3B8)

val CopperPrimaryDark = Color(0xFFE09145)
val CopperDeepDark = Color(0xFFD97706)
val CopperContainerDark = Color(0xFF2E2114)

val PlasticPrimaryDark = Color(0xFF38BDF8)
val PlasticDeepDark = Color(0xFF0EA5E9)
val PlasticContainerDark = Color(0xFF0F293A)

val EmeraldPrimaryDark = Color(0xFF10B981)
val EmeraldContainerDark = Color(0xFF0D2E25)

val DangerPrimaryDark = Color(0xFFF43F5E)
val DangerContainerDark = Color(0xFF35131E)

val WarningPrimaryDark = Color(0xFFF59E0B)
val WarningContainerDark = Color(0xFF33260F)

// Clean Light Palette (Daytime Factory Floor)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFF1F5F9)
val LightCard = Color(0xFFFFFFFF)
val LightCardElevated = Color(0xFFF8FAFC)
val LightBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)

val CopperPrimaryLight = Color(0xFFB45309)
val CopperDeepLight = Color(0xFFD97706)
val CopperContainerLight = Color(0xFFFEF3C7)

val PlasticPrimaryLight = Color(0xFF0284C7)
val PlasticDeepLight = Color(0xFF0EA5E9)
val PlasticContainerLight = Color(0xFFE0F2FE)

val EmeraldPrimaryLight = Color(0xFF059669)
val EmeraldContainerLight = Color(0xFFD1FAE5)

val DangerPrimaryLight = Color(0xFFE11D48)
val DangerContainerLight = Color(0xFFFFE4E6)

val WarningPrimaryLight = Color(0xFFD97706)
val WarningContainerLight = Color(0xFFFEF3C7)

@Immutable
data class SmcColors(
    val isDark: Boolean,
    val background: Color,
    val surface: Color,
    val card: Color,
    val cardElevated: Color,
    val border: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val copper: Color,
    val copperAccent: Color,
    val copperContainer: Color,
    val plastic: Color,
    val plasticAccent: Color,
    val plasticContainer: Color,
    val emerald: Color,
    val emeraldContainer: Color,
    val danger: Color,
    val dangerContainer: Color,
    val warning: Color,
    val warningContainer: Color
)

val DarkSmcColors = SmcColors(
    isDark = true,
    background = DarkBackground,
    surface = DarkSurface,
    card = DarkCard,
    cardElevated = DarkCardElevated,
    border = DarkBorder,
    textPrimary = DarkTextPrimary,
    textSecondary = DarkTextSecondary,
    copper = CopperPrimaryDark,
    copperAccent = CopperDeepDark,
    copperContainer = CopperContainerDark,
    plastic = PlasticPrimaryDark,
    plasticAccent = PlasticDeepDark,
    plasticContainer = PlasticContainerDark,
    emerald = EmeraldPrimaryDark,
    emeraldContainer = EmeraldContainerDark,
    danger = DangerPrimaryDark,
    dangerContainer = DangerContainerDark,
    warning = WarningPrimaryDark,
    warningContainer = WarningContainerDark
)

val LightSmcColors = SmcColors(
    isDark = false,
    background = LightBackground,
    surface = LightSurface,
    card = LightCard,
    cardElevated = LightCardElevated,
    border = LightBorder,
    textPrimary = LightTextPrimary,
    textSecondary = LightTextSecondary,
    copper = CopperPrimaryLight,
    copperAccent = CopperDeepLight,
    copperContainer = CopperContainerLight,
    plastic = PlasticPrimaryLight,
    plasticAccent = PlasticDeepLight,
    plasticContainer = PlasticContainerLight,
    emerald = EmeraldPrimaryLight,
    emeraldContainer = EmeraldContainerLight,
    danger = DangerPrimaryLight,
    dangerContainer = DangerContainerLight,
    warning = WarningPrimaryLight,
    warningContainer = WarningContainerLight
)

val LocalSmcColors = staticCompositionLocalOf { DarkSmcColors }

package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val SmcDarkColorScheme = darkColorScheme(
    primary = CopperPrimaryDark,
    onPrimary = Color(0xFF1A0F03),
    primaryContainer = CopperContainerDark,
    onPrimaryContainer = CopperPrimaryDark,
    secondary = PlasticPrimaryDark,
    onSecondary = Color(0xFF041C2B),
    secondaryContainer = PlasticContainerDark,
    onSecondaryContainer = PlasticPrimaryDark,
    tertiary = EmeraldPrimaryDark,
    onTertiary = Color(0xFF032117),
    tertiaryContainer = EmeraldContainerDark,
    onTertiaryContainer = EmeraldPrimaryDark,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkCard,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkBorder,
    outlineVariant = DarkBorder,
    error = DangerPrimaryDark,
    onError = Color.White,
    errorContainer = DangerContainerDark,
    onErrorContainer = DangerPrimaryDark
)

private val SmcLightColorScheme = lightColorScheme(
    primary = CopperPrimaryLight,
    onPrimary = Color.White,
    primaryContainer = CopperContainerLight,
    onPrimaryContainer = CopperPrimaryLight,
    secondary = PlasticPrimaryLight,
    onSecondary = Color.White,
    secondaryContainer = PlasticContainerLight,
    onSecondaryContainer = PlasticPrimaryLight,
    tertiary = EmeraldPrimaryLight,
    onTertiary = Color.White,
    tertiaryContainer = EmeraldContainerLight,
    onTertiaryContainer = EmeraldPrimaryLight,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightCard,
    onSurfaceVariant = LightTextSecondary,
    outline = LightBorder,
    outlineVariant = LightBorder,
    error = DangerPrimaryLight,
    onError = Color.White,
    errorContainer = DangerContainerLight,
    onErrorContainer = DangerPrimaryLight
)

@Composable
fun SmcCablesTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) SmcDarkColorScheme else SmcLightColorScheme
    val smcColors = if (darkTheme) DarkSmcColors else LightSmcColors

    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalSmcColors provides smcColors
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppTypography,
            content = content
        )
    }
}

object SmcTheme {
    val colors: SmcColors
        @Composable get() = LocalSmcColors.current
}

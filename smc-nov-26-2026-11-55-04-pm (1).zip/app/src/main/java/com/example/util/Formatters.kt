package com.example.util

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

object Formatters {
    private val usSymbols = DecimalFormatSymbols(Locale.US)

    fun formatNumber(value: Double, maxDecimals: Int = 2): String {
        val safeValue = if (value.isNaN() || value.isInfinite()) 0.0 else value
        val pattern = if (maxDecimals <= 0) {
            "#,##0"
        } else {
            "#,##0.${"#".repeat(maxDecimals)}"
        }
        return DecimalFormat(pattern, usSymbols).format(safeValue)
    }

    fun formatKg(kg: Double): String = "${formatNumber(kg, 2)} كغ"

    fun formatKgCompact(kg: Double): String {
        return if (abs(kg) >= 1000.0) {
            "${formatNumber(kg, 1)} كغ"
        } else {
            "${formatNumber(kg, 2)} كغ"
        }
    }

    fun formatDualLength(meters: Double): String {
        val km = meters / 1000.0
        return "${formatNumber(meters, 1)} م (${formatNumber(km, 3)} كم)"
    }

    fun formatGramsPerMeter(gm: Double): String = "${formatNumber(gm, 2)} غ/م"

    fun formatMm(mm: Double): String = "${formatNumber(mm, 2)} مم"

    fun formatArea(mm2: Double): String = "${formatNumber(mm2, 2)} مم²"

    fun formatTimestamp(millis: Long): String {
        val sdf = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.US)
        return sdf.format(Date(millis))
    }

    fun formatDeltaKg(delta: Double): String {
        val sign = if (delta >= 0) "+" else "-"
        return "$sign${formatNumber(abs(delta), 2)} كغ"
    }

    fun parseDoubleSafe(raw: String): Double? {
        val normalized = raw
            .trim()
            .replace('٫', '.')
            .replace(',', '.')
            .replace('٠', '0')
            .replace('١', '1')
            .replace('٢', '2')
            .replace('٣', '3')
            .replace('٤', '4')
            .replace('٥', '5')
            .replace('٦', '6')
            .replace('٧', '7')
            .replace('٨', '8')
            .replace('٩', '9')
        return normalized.toDoubleOrNull()
    }
}

package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.CalculatorResults
import com.example.data.CalculatorState
import com.example.data.FactoryOrder
import com.example.data.FactoryRepository
import com.example.data.InventoryIds
import com.example.data.InventoryItemEntity
import com.example.data.InventoryLogEntity
import com.example.data.LengthUnit
import com.example.data.MaterialCategory
import com.example.data.PresetCategory
import com.example.data.PresetEntity
import com.example.data.ThemePreferences
import com.example.util.Formatters
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AppTab(val route: String, val labelAr: String) {
    ORDERS("orders", "الأوردرات"),
    INVENTORY("inventory", "المخزون"),
    CALCULATOR("calculator", "حاسبة الكبل"),
    ARCHIVE("archive", "الأرشيف")
}

enum class ToastTone {
    SUCCESS,
    INFO,
    ERROR
}

data class ToastMessage(
    val id: Long = System.currentTimeMillis(),
    val text: String,
    val tone: ToastTone = ToastTone.SUCCESS
)

data class FactoryUiState(
    val isDarkTheme: Boolean = true,
    val inventory: List<InventoryItemEntity> = emptyList(),
    val logs: List<InventoryLogEntity> = emptyList(),
    val activeOrders: List<FactoryOrder> = emptyList(),
    val archivedOrders: List<FactoryOrder> = emptyList(),
    val presets: List<PresetEntity> = emptyList(),
    val calculator: CalculatorState = CalculatorState(),
    val toast: ToastMessage? = null
) {
    val copperItem: InventoryItemEntity?
        get() = inventory.firstOrNull { it.id == InventoryIds.COPPER }

    val plasticItems: List<InventoryItemEntity>
        get() = inventory.filter { it.category == MaterialCategory.PLASTIC.code }.sortedBy { it.sortOrder }

    val copperKg: Double
        get() = copperItem?.quantityKg ?: 0.0

    val totalPlasticKg: Double
        get() = plasticItems.sumOf { it.quantityKg }

    fun presetsFor(category: PresetCategory): List<PresetEntity> =
        presets.filter { it.category == category.code }

    val calculatorResults: CalculatorResults
        get() = CalculatorResults.compute(
            d = Formatters.parseDoubleSafe(calculator.copperDiameterStr) ?: 0.0,
            D = Formatters.parseDoubleSafe(calculator.outerDiameterStr) ?: 0.0,
            plasticDensity = Formatters.parseDoubleSafe(calculator.plasticDensityStr) ?: 0.0,
            copperDensity = Formatters.parseDoubleSafe(calculator.copperDensityStr) ?: 8.96,
            lengthInput = Formatters.parseDoubleSafe(calculator.lengthStr) ?: 0.0,
            lengthUnit = calculator.lengthUnit,
            cores = calculator.coresStr.trim().toIntOrNull() ?: 1
        )
}

class FactoryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = FactoryRepository(
        database = AppDatabase.getInstance(application),
        preferences = ThemePreferences(application)
    )

    private val calculatorState = MutableStateFlow(CalculatorState())
    private val toastState = MutableStateFlow<ToastMessage?>(null)
    private var toastJob: Job? = null

    private val coreDataFlow = combine(
        repository.isDarkTheme,
        repository.inventory,
        repository.logs,
        repository.activeOrders,
        repository.archivedOrders
    ) { isDark, inventory, logs, active, archived ->
        CoreData(isDark, inventory, logs, active, archived)
    }

    val uiState: StateFlow<FactoryUiState> = combine(
        coreDataFlow,
        repository.presets,
        calculatorState,
        toastState
    ) { core, presets, calc, toast ->
        FactoryUiState(
            isDarkTheme = core.isDark,
            inventory = core.inventory,
            logs = core.logs,
            activeOrders = core.active,
            archivedOrders = core.archived,
            presets = presets,
            calculator = calc,
            toast = toast
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = FactoryUiState()
    )

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
        }
    }

    private fun showToast(text: String, tone: ToastTone = ToastTone.SUCCESS) {
        toastJob?.cancel()
        toastState.value = ToastMessage(text = text, tone = tone)
        toastJob = viewModelScope.launch {
            delay(2800)
            toastState.value = null
        }
    }

    fun dismissToast() {
        toastJob?.cancel()
        toastState.value = null
    }

    fun toggleTheme() {
        val next = !uiState.value.isDarkTheme
        viewModelScope.launch {
            repository.setDarkTheme(next)
        }
    }

    // --- Inventory Actions ---

    fun setMaterialBalance(materialId: String, newBalanceKg: Double, note: String = "") {
        viewModelScope.launch {
            repository.setMaterialBalance(materialId, newBalanceKg, note)
            showToast("تم تحديث الرصيد إلى ${Formatters.formatKg(newBalanceKg.coerceAtLeast(0.0))}")
        }
    }

    fun adjustMaterialBalance(materialId: String, deltaKg: Double, note: String = "") {
        if (deltaKg == 0.0) return
        val label = if (deltaKg > 0) "إضافة للمخزون" else "خصم من المخزون"
        viewModelScope.launch {
            repository.adjustMaterialBalance(materialId, deltaKg, label, note)
            val prefix = if (deltaKg > 0) "تمت إضافة" else "تم خصم"
            showToast("$prefix ${Formatters.formatKg(kotlin.math.abs(deltaKg))} بنجاح")
        }
    }

    fun renamePlastic(materialId: String, newName: String) {
        val trimmed = newName.trim()
        if (trimmed.isEmpty()) {
            showToast("يرجى إدخال اسم صالح لنوع البلاستيك", ToastTone.ERROR)
            return
        }
        viewModelScope.launch {
            repository.renameMaterial(materialId, trimmed)
            showToast("تم تحديث اسم نوع البلاستيك إلى «$trimmed»")
        }
    }

    fun clearInventoryLogs() {
        viewModelScope.launch {
            repository.clearAllLogs()
            showToast("تم مسح سجل حركة المستودع", ToastTone.INFO)
        }
    }

    // --- Presets Actions ---

    fun addPreset(category: PresetCategory, value: String) {
        val trimmed = value.trim()
        if (trimmed.isEmpty()) {
            showToast("يرجى كتابة قيمة قبل الإضافة", ToastTone.ERROR)
            return
        }
        viewModelScope.launch {
            repository.addPreset(category, trimmed)
            showToast("تم حفظ «$trimmed» في ${category.labelAr}")
        }
    }

    fun deletePreset(presetId: Long) {
        viewModelScope.launch {
            repository.deletePreset(presetId)
            showToast("تم حذف العنصر من القائمة المحفوظة", ToastTone.INFO)
        }
    }

    // --- Orders Actions ---

    fun saveOrder(order: FactoryOrder) {
        val isEdit = order.id != 0L
        viewModelScope.launch {
            repository.saveOrder(order)
            showToast(if (isEdit) "تم تحديث الأوردر ${order.orderNumber} بنجاح" else "تم إنشاء الأوردر ${order.orderNumber} بنجاح")
        }
    }

    fun toggleColorCheck(orderId: Long, wireId: String, colorId: String) {
        viewModelScope.launch {
            repository.toggleColorCheck(orderId, wireId, colorId)
        }
    }

    fun advanceOrderToStage2(orderId: Long) {
        viewModelScope.launch {
            repository.advanceOrderToStage2(orderId)
            showToast("تم الانتقال بنجاح إلى المرحلة الثانية")
        }
    }

    fun archiveOrder(orderId: Long) {
        viewModelScope.launch {
            repository.archiveOrder(orderId)
            showToast("تم نقل الأوردر إلى الأرشيف بنجاح")
        }
    }

    fun restoreOrder(orderId: Long) {
        viewModelScope.launch {
            repository.restoreOrder(orderId)
            showToast("تمت استعادة الأوردر إلى التشغيل")
        }
    }

    fun deleteOrder(orderId: Long, isArchived: Boolean = false) {
        viewModelScope.launch {
            repository.deleteOrder(orderId)
            showToast(
                if (isArchived) "تم حذف الأوردر نهائياً من الأرشيف" else "تم حذف الأوردر بنجاح",
                ToastTone.INFO
            )
        }
    }

    // --- Cable Engineering Calculator Actions ---

    fun updateCopperDiameter(value: String) {
        calculatorState.update { it.copy(copperDiameterStr = value) }
    }

    fun updateOuterDiameter(value: String) {
        calculatorState.update { it.copy(outerDiameterStr = value) }
    }

    fun updatePlasticDensity(value: String, presetLabel: String = "") {
        calculatorState.update {
            it.copy(plasticDensityStr = value, selectedPlasticPresetLabel = presetLabel)
        }
    }

    fun updateCopperDensity(value: String) {
        calculatorState.update { it.copy(copperDensityStr = value) }
    }

    fun updateCalcLength(value: String) {
        calculatorState.update { it.copy(lengthStr = value) }
    }

    fun updateCalcLengthUnit(unit: LengthUnit) {
        calculatorState.update { current ->
            if (current.lengthUnit == unit) current
            else {
                val parsed = Formatters.parseDoubleSafe(current.lengthStr)
                val converted = if (parsed != null && parsed > 0) {
                    val newVal = if (unit == LengthUnit.KILOMETERS) parsed / 1000.0 else parsed * 1000.0
                    Formatters.formatNumber(newVal, 3).replace(",", "")
                } else {
                    current.lengthStr
                }
                current.copy(lengthUnit = unit, lengthStr = converted)
            }
        }
    }

    fun updateCalcCores(value: String) {
        val filtered = value.filter { it.isDigit() }.take(3)
        calculatorState.update { it.copy(coresStr = filtered) }
    }

    fun deductCalculatorFromInventory(plasticId: String, customNote: String) {
        val results = uiState.value.calculatorResults
        if (!results.isValid) {
            showToast("يرجى التأكد من صحة أبعاد الكبل قبل الخصم", ToastTone.ERROR)
            return
        }
        val autoNote = buildString {
            append("حاسبة الكبل: d=${Formatters.formatNumber(results.copperDiameterMm, 2)}مم، ")
            append("D=${Formatters.formatNumber(results.outerDiameterMm, 2)}مم، ")
            append("${results.coresCount} فردة، ${Formatters.formatDualLength(results.lengthMeters)}")
            if (customNote.isNotBlank()) append(" — ${customNote.trim()}")
        }
        viewModelScope.launch {
            repository.deductFromCalculator(
                copperKg = results.copperKg,
                plasticId = plasticId,
                plasticKg = results.plasticKg,
                note = autoNote
            )
            showToast(
                "تم خصم ${Formatters.formatKg(results.copperKg)} نحاس و ${Formatters.formatKg(results.plasticKg)} بلاستيك"
            )
        }
    }

    private data class CoreData(
        val isDark: Boolean,
        val inventory: List<InventoryItemEntity>,
        val logs: List<InventoryLogEntity>,
        val active: List<FactoryOrder>,
        val archived: List<FactoryOrder>
    )
}
